package stra.werecord.impl.media;
import android.app.Application;
import android.graphics.Bitmap;
import java.io.ByteArrayOutputStream;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.Config;
import org.robolectric.annotation.GraphicsMode;
import static org.junit.Assert.*;
@RunWith(RobolectricTestRunner.class)
@Config(sdk=35,application=Application.class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
public class ImageBitmapDecodeTest {
    @Test public void actualPngAndXorDatProduceTheSameViewableBitmap() throws Exception {
        Bitmap fixture=Bitmap.createBitmap(80,40,Bitmap.Config.ARGB_8888);fixture.eraseColor(0xff336699);
        ByteArrayOutputStream out=new ByteArrayOutputStream();assertTrue(fixture.compress(Bitmap.CompressFormat.PNG,100,out));fixture.recycle();
        byte[] bytes=out.toByteArray();
        for(int key:new int[]{0,73}) {
            byte[] encoded=bytes.clone();for(int i=0;i<encoded.length;i++)encoded[i]=(byte)(encoded[i]^key);
            Bitmap decoded=MessageImageLoader.decodeBitmap(encoded);
            assertEquals(80,decoded.getWidth());assertEquals(40,decoded.getHeight());assertEquals(0xff336699,decoded.getPixel(20,10));decoded.recycle();
        }
    }
}
