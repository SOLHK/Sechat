package stra.werecord.impl.model.account;
import android.app.Application;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.Config;
import stra.werecord.impl.Environment;
import static org.junit.Assert.*;
@RunWith(RobolectricTestRunner.class)
@Config(sdk=35,application=Application.class)
public class AccountProfileTest {
    @Test public void readsEscapedNicknameAndRejectsDifferentAccount() throws Exception {
        Environment.create(); User user=new User("123");
        java.util.Map<String,String> prefs=AccountProfile.readPreferences("<map><int name='last_login_uin' value='456'/><string name='last_login_username'>wxid_self</string><string name='last_login_nick_name'>名字 &amp; 昵称</string><string name='last_login_alias'>wechat_name</string></map>");
        AccountProfile.apply(user,prefs); assertNull(user.id);assertNull(user.nickname);
        prefs.put("last_login_uin","123"); AccountProfile.apply(user,prefs);
        assertEquals("wxid_self",user.id); assertEquals("名字 & 昵称",user.getDisplayNickname());
        assertEquals("微信号：wechat_name",user.getDisplayWechatNumber());
        user.nickname="数据库昵称"; AccountProfile.apply(user,prefs);assertEquals("数据库昵称",user.nickname);
    }
    @Test public void missingIdentityIsExplicitAndNeverGuessed() {
        Environment.create(); User user=new User("123");
        assertEquals("未读取到微信昵称",user.getDisplayNickname()); assertEquals("未读取到微信号",user.getDisplayWechatNumber());
        java.util.Map<String,String> prefs=new java.util.HashMap<>(); prefs.put("last_login_nickname","其他用户");
        AccountProfile.apply(user,prefs); assertNull(user.nickname);
    }
}
