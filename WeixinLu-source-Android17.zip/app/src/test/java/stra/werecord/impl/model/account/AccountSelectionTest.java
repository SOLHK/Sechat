package stra.werecord.impl.model.account;
import java.util.*;
import org.junit.Test;
import static org.junit.Assert.*;
public class AccountSelectionTest {
    @Test public void uinsAreValidatedAndDeduplicatedWithoutGuessing() {
        assertEquals(Arrays.asList("123","456"),AccountSelection.candidates("123",Arrays.asList("123","456","0","微信","../123","4294967296","-2147483649")));
        assertEquals(Collections.singletonList("123"),AccountSelection.candidates("123",null));
        assertEquals(Arrays.asList("123","456"),AccountSelection.preferenceValues("<map><int name='uin' value='123'/><string name='other'>456</string><string name='name'>微信</string></map>"));
    }
    @Test public void preferredDatabaseWinsAndMissingDatabaseFallsBack() {
        List<String> available=Arrays.asList("111","222");
        assertEquals("222",AccountSelection.choose(available,"222","111"));
        assertEquals("111",AccountSelection.choose(available,"333","111"));
        assertEquals("111",AccountSelection.choose(available,"333","444"));
        assertThrows(IllegalArgumentException.class,()->AccountSelection.choose(Collections.emptyList(),"111","222"));
    }
}
