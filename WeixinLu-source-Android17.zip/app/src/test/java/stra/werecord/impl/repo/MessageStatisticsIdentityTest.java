package stra.werecord.impl.repo;

import org.junit.Test;
import static org.junit.Assert.*;

public class MessageStatisticsIdentityTest {
    @Test public void missingAccountIdHasNonNullSelfIdentity() {
        assertEquals(MessageRepository.STATISTICS_SELF, MessageRepository.statisticsSelfId(null));
        assertEquals(MessageRepository.STATISTICS_SELF, MessageRepository.statisticsSelfId(""));
        assertEquals(MessageRepository.STATISTICS_SELF, MessageRepository.statisticsSelfId("  "));
    }

    @Test public void knownAccountIdIsPreserved() {
        assertEquals("wxid_real", MessageRepository.statisticsSelfId("wxid_real"));
    }
}
