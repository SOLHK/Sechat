package stra.werecord.impl.media;
import java.util.*;
import java.io.IOException;
import org.junit.Test;
import static org.junit.Assert.*;
public class LocalImageFilesTest {
    @Test public void normalAndXorContainersRoundTrip() throws Exception {
        for(byte[] magic:new byte[][]{{(byte)255,(byte)216,(byte)255,1,2},{(byte)137,80,78,71,13,10,26,10},{71,73,70,56,57,97},{82,73,70,70,0,0,0,0,87,69,66,80}}) {
            assertArrayEquals(magic,LocalImageFiles.decodeContainer(magic));
            for(int key:new int[]{1,37,127,255}) {
                byte[] encoded=magic.clone();for(int i=0;i<encoded.length;i++)encoded[i]=(byte)(encoded[i]^key);
                assertArrayEquals(magic,LocalImageFiles.decodeContainer(encoded));
            }
        }
    }
    @Test public void unknownEncryptedAndMalformedFilesGiveAnError() {
        for(byte[] data:new byte[][]{{},{1,2},{7,8,0,0,20,32,1,1},{82,73,70,70,0,0,0,0,1,2,3,4}})
            assertThrows(IOException.class,()->LocalImageFiles.decodeContainer(data));
    }
    @Test public void identifiersCannotEscapeMediaFolders() {
        String hash="0123456789abcdef0123456789abcdef";
        assertEquals(Collections.singletonList(hash),LocalImageFiles.hashes("THUMBNAIL_DIRPATH://th_"+hash));
        assertTrue(LocalImageFiles.hashes("T_a","../../file").isEmpty());
        List<String> paths=LocalImageFiles.candidates(Collections.singletonList("/cache"),Arrays.asList(hash,"../../file"));
        assertEquals("/cache/01/23/"+hash,paths.get(0));
        assertTrue(paths.contains("/cache/01/23/th_"+hash));
        assertFalse(paths.stream().anyMatch(s->s.contains("..")));
        assertEquals("'a'\\''b'",LocalImageFiles.quote("a'b"));
    }
    @Test public void hugeImagesAreSampledBeforeAllocation() throws Exception {
        assertEquals(1,LocalImageFiles.sampleSize(800,600));
        assertEquals(4,LocalImageFiles.sampleSize(6000,4000));
        int sample=LocalImageFiles.sampleSize(100000,100000);
        assertTrue(100000L/sample*100000/sample<=2560000L);
        assertThrows(IOException.class,()->LocalImageFiles.sampleSize(-1,0));
    }
}
