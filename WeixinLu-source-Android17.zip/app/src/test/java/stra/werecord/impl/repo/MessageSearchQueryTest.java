package stra.werecord.impl.repo;
import android.app.Application;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.Config;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class)
@Config(sdk=35, application=Application.class)
public class MessageSearchQueryTest {
    @Test public void largeHistoryIsReadAsBoundedStablePages() {
        try(SQLiteDatabase db=SQLiteDatabase.create(null)) {
            db.execSQL("create table message(msgId integer primary key,createTime integer,talker text,content text)");
            db.execSQL("with recursive n(x) as (select 1 union all select x+1 from n where x<430000) "
                    + "insert into message select x, x/4, 'friend', 'hello' from n");
            long time=Long.MAX_VALUE,id=Long.MAX_VALUE,lastId=Long.MAX_VALUE;
            for(int page=0;page<3;page++) {
                try(Cursor c=db.rawQuery(MessageSearchQuery.SQL,MessageSearchQuery.args("friend","hello",time,id))) {
                    assertEquals(60,c.getCount());
                    while(c.moveToNext()) {
                        long next=c.getLong(c.getColumnIndexOrThrow("msgId")); assertTrue(next<lastId);
                        lastId=next; time=c.getLong(c.getColumnIndexOrThrow("createTime")); id=next;
                    }
                }
            }
            assertEquals(430000-180+1,lastId);
            try(Cursor c=db.rawQuery(MessageSearchQuery.SQL,MessageSearchQuery.args("other","hello",Long.MAX_VALUE,Long.MAX_VALUE))) { assertEquals(0,c.getCount()); }
        }
    }
    @Test public void wildcardsQuotesAndBackslashAreLiteral() {
        try(SQLiteDatabase db=SQLiteDatabase.create(null)) {
            db.execSQL("create table message(msgId integer,createTime integer,talker text,content text)");
            db.execSQL("insert into message values(1,1,'friend',?)",new Object[]{"100%_O'Neil\\notes"});
            db.execSQL("insert into message values(2,2,'friend','100XXOZZ')");
            try(Cursor c=db.rawQuery(MessageSearchQuery.SQL,MessageSearchQuery.args("friend","%_O'Neil\\",Long.MAX_VALUE,Long.MAX_VALUE))) { assertEquals(1,c.getCount()); }
        }
    }
}
