package stra.werecord.impl.stats;

import android.app.Application;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.Config;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class)
@Config(sdk=35, application=Application.class)
public class StatsQueryTest {
    @Test public void groupCountsAndTimesPreserveUnknownAndSystemMessages() {
        try (SQLiteDatabase db=SQLiteDatabase.create(null)) {
            db.execSQL("create table message(type integer,isSend integer,content text,createTime integer,talker text)");
            db.execSQL("insert into message values(1,0,'alice:' || char(10) || 'hello',10,'room@chatroom')");
            db.execSQL("insert into message values(1,0,'alice:' || char(10) || 'again',20,'room@chatroom')");
            db.execSQL("insert into message values(1,1,null,30,'room@chatroom')");
            db.execSQL("insert into message values(10000,1,'system',40,'room@chatroom')");
            db.execSQL("insert into message values(3,0,null,50,'room@chatroom')");
            db.execSQL("insert into message values(1,0,'ignored',60,'different')");
            long total=0; boolean alice=false,self=false,system=false,unknown=false;
            try(Cursor c=db.rawQuery(StatsQuery.build(true),new String[]{"self","room@chatroom"})) {
                while(c.moveToNext()) {
                    total+=c.getLong(2);
                    if("alice".equals(c.getString(1))) {alice=true;assertEquals(2,c.getLong(2));assertEquals(10,c.getLong(3));assertEquals(20,c.getLong(4));}
                    if("self".equals(c.getString(1))) self=true;
                    if(c.getInt(0)==10000) {system=true;assertTrue(c.isNull(1));}
                    if(c.getInt(0)==3) {unknown=true;assertTrue(c.isNull(1));}
                }
            }
            assertEquals(5,total);assertTrue(alice&&self&&system&&unknown);
        }
    }
    @Test public void privateIdentityDoesNotParseContentAsGroupPrefix() {
        try(SQLiteDatabase db=SQLiteDatabase.create(null)) {
            db.execSQL("create table message(type integer,isSend integer,content text,createTime integer,talker text)");
            db.execSQL("insert into message values(1,0,'fake:' || char(10) || 'text',10,'friend')");
            db.execSQL("insert into message values(1,1,null,20,'friend')");
            try(Cursor c=db.rawQuery(StatsQuery.build(false),new String[]{"self","friend","friend"})) {
                assertEquals(2,c.getCount());
                while(c.moveToNext()) assertTrue("self".equals(c.getString(1))||"friend".equals(c.getString(1)));
            }
        }
    }
}
