package stra.werecord.ui;

import android.app.Application;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.view.LayoutInflater;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;
import androidx.databinding.ViewDataBinding;
import java.io.File;
import java.io.FileOutputStream;
import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import java.time.Duration;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.annotation.Config;
import org.robolectric.annotation.GraphicsMode;
import static org.robolectric.Shadows.shadowOf;
import static org.junit.Assert.*;
import stra.werecord.App;
import stra.werecord.R;
import stra.werecord.databinding.ActivityMainBinding;
import stra.werecord.ui.customview.BottomBar;
import stra.werecord.ui.customview.MainPanel;
import stra.werecord.ui.viewmodel.PageConfig;
import stra.werecord.ui.viewmodel.PageViewModel;

@RunWith(RobolectricTestRunner.class)
@Config(sdk=35, application=Application.class, qualifiers="zh-rCN-w360dp-h780dp-xxhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
public class ExpressiveUiTest {
    private AppCompatActivity host() throws Exception {
        Field field = App.class.getDeclaredField("sApplicationContext");
        field.setAccessible(true);
        field.set(null, new WeakReference<>(RuntimeEnvironment.getApplication()));
        var controller = Robolectric.buildActivity(AppCompatActivity.class);
        AppCompatActivity activity = controller.get();
        activity.setTheme(R.style.Base_AppTheme);
        controller.create().start().resume();
        return activity;
    }
    private void render(View root, String name) throws Exception {
        root.measure(View.MeasureSpec.makeMeasureSpec(1080, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(2340, View.MeasureSpec.EXACTLY));
        root.layout(0,0,1080,2340);
        Bitmap bitmap = Bitmap.createBitmap(1080,2340,Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        canvas.drawColor(root.getResources().getColor(R.color.stra_canvas,root.getContext().getTheme()));
        root.draw(canvas);
        File dir = new File("../qa"); dir.mkdirs();
        try (FileOutputStream out = new FileOutputStream(new File(dir,name+".png"))) {
            bitmap.compress(Bitmap.CompressFormat.PNG,100,out);
        }
        bitmap.recycle();
    }
    @Test public void navigationAndFilterStayUsable() throws Exception {
        AppCompatActivity activity = host();
        ActivityMainBinding binding = DataBindingUtil.inflate(LayoutInflater.from(activity),R.layout.activity_main,null,false);
        PageConfig config = new PageConfig(); config.caption="记录";
        config.setEventHandler(new PageConfig.EventHandler() {
            public void onConfirmFilter() {} public void onResetFilter() {} public void onSearch(String value) {}
        });
        PageViewModel model = new PageViewModel(); model.updateCurrentConfig(config);
        binding.setModel(model); binding.executePendingBindings();
        BottomBar bar = binding.mainBottomBar;
        int[] callback = {-1};
        bar.setOnItemSelectListener((index,caption,unchanged) -> callback[0]=index);
        bar.setSelection(2);
        assertEquals(2,bar.getSelection()); assertEquals(2,callback[0]);
        assertEquals("工作台",bar.getCurrentCaption().toString());
        bar.setSelection(0);
        render(binding.getRoot(),"main-light");
        assertTrue(bar.getHeight()>0); assertTrue(bar.getBottom()<=2340);
        MainPanel panel = binding.mainPanel;
        panel.setSlideEnabled(true); panel.openPanel(); assertTrue(panel.isOpen());
        shadowOf(android.os.Looper.getMainLooper()).idleFor(Duration.ofMillis(300));
        assertEquals(View.VISIBLE,binding.llCurtain.getVisibility());
        binding.mask.performClick(); assertFalse(panel.isOpen());
        shadowOf(android.os.Looper.getMainLooper()).idleFor(Duration.ofMillis(300));
        assertEquals(View.GONE,binding.llCurtain.getVisibility());
    }
    @Test public void primaryScreensInflateInBothThemes() throws Exception {
        for (String theme : new String[]{"light","dark"}) {
            RuntimeEnvironment.setQualifiers("zh-rCN-w360dp-h780dp"+(theme.equals("dark")?"-night":"-notnight")+"-xxhdpi");
            AppCompatActivity activity = host();
            for (int id : new int[]{R.layout.fragment_mine,R.layout.fragment_stats,R.layout.activity_message,R.layout.fragment_filter,R.layout.fragment_contact}) {
                ViewDataBinding binding = DataBindingUtil.inflate(LayoutInflater.from(activity),id,null,false);
                binding.executePendingBindings();
                render(binding.getRoot(),activity.getResources().getResourceEntryName(id)+"-"+theme);
                assertTrue(binding.getRoot().getMeasuredHeight()>0);
            }
            View about = LayoutInflater.from(activity).inflate(R.layout.dialog_about,null,false);
            render(about,"about-"+theme);
        }
    }

    @Test public void conversationNavigationKeepsSearchSeparateAndReturnsToMessages() throws Exception {
        for(String mode : new String[]{"light", "dark"}) {
            RuntimeEnvironment.setQualifiers("zh-rCN-w360dp-h780dp"+(mode.equals("dark")?"-night":"-notnight")+"-xxhdpi");
            AppCompatActivity activity=host();
            stra.werecord.databinding.ActivityMessageBinding binding=DataBindingUtil.inflate(LayoutInflater.from(activity),R.layout.activity_message,null,false);
            binding.setModel(new stra.werecord.ui.viewmodel.MessageViewModel());
            activity.setContentView(binding.getRoot());
            binding.vpMessage.setAdapter(new androidx.viewpager2.adapter.FragmentStateAdapter(activity) {
                @Override public int getItemCount() { return 3; }
                @Override public androidx.fragment.app.Fragment createFragment(int index) {
                    return new androidx.fragment.app.Fragment();
                }
            });
            binding.executePendingBindings();
            render(binding.getRoot(),"conversation-records-"+mode);
            assertFalse(binding.messagePanel.isOpen());
            binding.ibStats.performClick();
            assertTrue(binding.messagePanel.isOpen());
            assertEquals(View.GONE,binding.etSearch.getVisibility());
            int navWidth=binding.bottomBar.getWidth();
            binding.ibSearch.performClick();
            assertEquals(2,binding.vpMessage.getCurrentItem());
            assertEquals(View.VISIBLE,binding.etSearch.getVisibility());
            render(binding.getRoot(),"conversation-search-"+mode);
            assertEquals(navWidth,binding.bottomBar.getWidth());
            binding.ibMessages.performClick();
            assertFalse(binding.messagePanel.isOpen());
            assertEquals(View.GONE,binding.llCurtain.getVisibility());
            assertEquals(View.GONE,binding.ibEdit.getVisibility());
            binding.ibEdit.performClick();
            assertFalse(binding.messagePanel.isOpen());
            binding.vpMessage.setCurrentItem(1,false);
            assertEquals(0,binding.vpMessage.getCurrentItem());
            assertFalse(binding.vpMessage.isUserInputEnabled());
            binding.messagePanel.setEditMode(true);
            assertEquals(View.VISIBLE,binding.ibEdit.getVisibility());
            binding.ibEdit.performClick();
            assertEquals(1,binding.vpMessage.getCurrentItem());
            binding.messagePanel.setEditMode(false);
            assertEquals(View.GONE,binding.ibEdit.getVisibility());
            assertFalse(binding.messagePanel.isOpen());
            assertEquals(View.GONE,binding.etSearch.getVisibility());
        }
    }
    @Test public void realisticStatisticsFitAndLongRecordsWrap() throws Exception {
        for (String mode : new String[]{"light","dark"}) {
            RuntimeEnvironment.setQualifiers("zh-rCN-w360dp-h780dp"+(mode.equals("dark")?"-night":"-notnight")+"-xxhdpi");
            AppCompatActivity activity=host();
            stra.werecord.databinding.FragmentStatsBinding stats=DataBindingUtil.inflate(LayoutInflater.from(activity),R.layout.fragment_stats,null,false);
            stats.executePendingBindings();
            stats.mask.setVisibility(View.GONE);
            stats.tvOverview.setText("431,637");
            stats.tvSummaryDetail.setText("不含系统消息");
            stats.tvTimeSpan.setText("起始  2023.05.14 01:36\n最近  2026.10.01 11:59");
            android.widget.LinearLayout preview=new android.widget.LinearLayout(activity);
            preview.setOrientation(android.widget.LinearLayout.VERTICAL);
            for (String[] row : new String[][]{{"文字","334358条","76.98%"},{"图片","56002条","12.9%"},{"其他","4395条","1.01%"}}) {
                ViewDataBinding item=DataBindingUtil.inflate(LayoutInflater.from(activity),R.layout.item_chart_msg_type,preview,false);
                item.executePendingBindings();
                ((android.widget.TextView)item.getRoot().findViewById(R.id.tv_name)).setText(row[0]);
                ((android.widget.TextView)item.getRoot().findViewById(R.id.tv_count)).setText(row[1]);
                ((android.widget.TextView)item.getRoot().findViewById(R.id.tv_consumed_time)).setText(row[2]);
                preview.addView(item.getRoot());
            }
            stats.rvStatsMsgType.setVisibility(View.GONE);
            ((android.view.ViewGroup)stats.overviewContainer.getParent()).addView(preview);
            render(stats.getRoot(),"statistics-populated-"+mode);
            assertEquals(1,stats.tvOverview.getLineCount());
            android.widget.LinearLayout feed=new android.widget.LinearLayout(activity);
            feed.setOrientation(android.widget.LinearLayout.VERTICAL);
            for(int layout:new int[]{R.layout.item_bubble_plain_left,R.layout.item_bubble_complex_right}) {
                ViewDataBinding record=DataBindingUtil.inflate(LayoutInflater.from(activity),layout,feed,false);
                record.executePendingBindings();
                android.widget.TextView name=record.getRoot().findViewById(R.id.tv_name);
                if(name!=null) name.setText("记录参与者");
                android.widget.TextView text=record.getRoot().findViewById(R.id.tv_title);
                text.setVisibility(View.VISIBLE);text.setText("这是一段比较长的聊天记录，用来检查文字换行、卡片边界和左右间距是否正常。继续阅读时，每条消息的发送者和时间都应该清楚可见。");
                feed.addView(record.getRoot());
            }
            render(feed,"record-feed-"+mode);
            android.widget.TextView message=feed.getChildAt(0).findViewById(R.id.tv_title);
            assertTrue(message.getLineCount()>1);
            assertTrue(message.getRight()<=((android.view.ViewGroup)message.getParent()).getWidth());
        }
    }
    @Test public void telegramScreensShowRealisticRowsAndAccount() throws Exception {
        for(String mode:new String[]{"light","dark"}) {
            RuntimeEnvironment.setQualifiers("zh-rCN-w360dp-h780dp"+(mode.equals("dark")?"-night":"-notnight")+"-xxhdpi");
            AppCompatActivity activity=host();
            ActivityMainBinding main=DataBindingUtil.inflate(LayoutInflater.from(activity),R.layout.activity_main,null,false);
            PageConfig config=new PageConfig(); config.caption="联系人";
            config.setEventHandler(new PageConfig.EventHandler() {
                public void onConfirmFilter() {} public void onResetFilter() {} public void onSearch(String value) {}
            });
            PageViewModel vm=new PageViewModel(); vm.updateCurrentConfig(config); main.setModel(vm); main.executePendingBindings();
            main.mainBottomBar.setSelection(1);
            stra.werecord.databinding.FragmentContactBinding contacts=DataBindingUtil.inflate(LayoutInflater.from(activity),R.layout.fragment_contact,null,false);
            contacts.executePendingBindings(); contacts.rvList.setPadding(0,396,0,216);
            contacts.rvList.setAdapter(new androidx.recyclerview.widget.RecyclerView.Adapter<androidx.recyclerview.widget.RecyclerView.ViewHolder>() {
                public int getItemCount() { return 12; }
                public androidx.recyclerview.widget.RecyclerView.ViewHolder onCreateViewHolder(android.view.ViewGroup parent,int type) {
                    return new androidx.recyclerview.widget.RecyclerView.ViewHolder(LayoutInflater.from(activity).inflate(R.layout.item_contact,parent,false)) {};
                }
                public void onBindViewHolder(androidx.recyclerview.widget.RecyclerView.ViewHolder holder,int index) {
                    ((android.widget.TextView)holder.itemView.findViewById(R.id.tv_name)).setText(new String[]{"阿宁","白宇","陈先生","家人群聊","林晓","朋友"}[index%6]);
                    ((android.widget.ImageView)holder.itemView.findViewById(R.id.iv_avatar)).setImageResource(R.drawable.ic_baseline_person_add_24);
                }
            });
            main.vpMain.setVisibility(View.GONE);
            ((android.view.ViewGroup)main.vpMain.getParent()).addView(contacts.getRoot(),0);
            render(main.getRoot(),"telegram-contacts-"+mode);
            assertEquals(View.GONE,contacts.rvScroller.getVisibility());
            assertTrue(contacts.rvList.getChildCount()>4);
            stra.werecord.impl.Environment.create();
            stra.werecord.impl.model.account.User user=new stra.werecord.impl.model.account.User("123"); user.nickname="我的微信名字"; user.alias="wechat_account";
            stra.werecord.databinding.FragmentMineBinding mine=DataBindingUtil.inflate(LayoutInflater.from(activity),R.layout.fragment_mine,null,false);
            mine.setUser(user); mine.executePendingBindings(); render(mine.getRoot(),"telegram-account-"+mode);
            assertEquals("我的微信名字",mine.tvUsername.getText().toString());
            assertEquals("微信号：wechat_account",mine.tvId.getText().toString());
            stra.werecord.databinding.ActivityMessageBinding chat=DataBindingUtil.inflate(LayoutInflater.from(activity),R.layout.activity_message,null,false);
            chat.setModel(new stra.werecord.ui.viewmodel.MessageViewModel()); chat.executePendingBindings(); chat.tvTopBarTitle.setText("老婆");
            chat.rvMessage.setAdapter(new androidx.recyclerview.widget.RecyclerView.Adapter<androidx.recyclerview.widget.RecyclerView.ViewHolder>() {
                public int getItemCount() { return 7; }
                public int getItemViewType(int index) { return index%2==0 ? R.layout.item_bubble_plain_left : R.layout.item_bubble_plain_right; }
                public androidx.recyclerview.widget.RecyclerView.ViewHolder onCreateViewHolder(android.view.ViewGroup parent,int type) {
                    ViewDataBinding b=DataBindingUtil.inflate(LayoutInflater.from(activity),type,parent,false); b.executePendingBindings();
                    return new androidx.recyclerview.widget.RecyclerView.ViewHolder(b.getRoot()) {};
                }
                public void onBindViewHolder(androidx.recyclerview.widget.RecyclerView.ViewHolder holder,int index) {
                    ((android.widget.TextView)holder.itemView.findViewById(R.id.tv_title)).setText(new String[]{"还了","前天忘记叫你看了","好的，等你回来一起吃饭。","对了宝宝","这是一条比较长的消息，左右气泡应该自然换行，时间放在气泡底部，不再重复显示发送者大标题。","舅舅他们3号过来","知道啦"}[index]);
                    ((android.widget.TextView)holder.itemView.findViewById(R.id.tv_time)).setText("10.01 12:"+(40-index));
                    android.widget.TextView name=holder.itemView.findViewById(R.id.tv_name); if(name!=null) name.setText("老婆");
                }
            });
            render(chat.getRoot(),"telegram-chat-"+mode);
            assertEquals(View.GONE,chat.ibEdit.getVisibility());
            assertTrue(chat.rvMessage.getChildCount()>3);
        }
    }

}
