package stra.werecord.ui;

import android.app.Application;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.view.LayoutInflater;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;
import androidx.databinding.ViewDataBinding;
import java.io.File;
import java.io.FileOutputStream;
import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import java.time.Duration;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.annotation.Config;
import org.robolectric.annotation.GraphicsMode;
import static org.robolectric.Shadows.shadowOf;
import static org.junit.Assert.*;
import stra.werecord.App;
import stra.werecord.R;
import stra.werecord.databinding.ActivityMainBinding;
import stra.werecord.ui.customview.BottomBar;
import stra.werecord.ui.customview.MainPanel;
import stra.werecord.ui.viewmodel.PageConfig;
import stra.werecord.ui.viewmodel.PageViewModel;

@RunWith(RobolectricTestRunner.class)
@Config(sdk=35, application=Application.class, qualifiers="zh-rCN-w360dp-h780dp-xxhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
public class ExpressiveUiTest {
    private AppCompatActivity host() throws Exception {
        Field field = App.class.getDeclaredField("sApplicationContext");
        field.setAccessible(true);
        field.set(null, new WeakReference<>(RuntimeEnvironment.getApplication()));
        var controller = Robolectric.buildActivity(AppCompatActivity.class);
        AppCompatActivity activity = controller.get();
        activity.setTheme(R.style.Base_AppTheme);
        controller.create().start().resume();
        return activity;
    }
    private void render(View root, String name) throws Exception {
        root.measure(View.MeasureSpec.makeMeasureSpec(1080, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(2340, View.MeasureSpec.EXACTLY));
        root.layout(0,0,1080,2340);
        Bitmap bitmap = Bitmap.createBitmap(1080,2340,Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        canvas.drawColor(root.getResources().getColor(R.color.stra_canvas,root.getContext().getTheme()));
        root.draw(canvas);
        File dir = new File("../qa"); dir.mkdirs();
        try (FileOutputStream out = new FileOutputStream(new File(dir,name+".png"))) {
            bitmap.compress(Bitmap.CompressFormat.PNG,100,out);
        }
        bitmap.recycle();
    }
    @Test public void navigationAndFilterStayUsable() throws Exception {
        AppCompatActivity activity = host();
        ActivityMainBinding binding = DataBindingUtil.inflate(LayoutInflater.from(activity),R.layout.activity_main,null,false);
        PageConfig config = new PageConfig(); config.caption="记录";
        config.setEventHandler(new PageConfig.EventHandler() {
            public void onConfirmFilter() {} public void onResetFilter() {} public void onSearch(String value) {}
        });
        PageViewModel model = new PageViewModel(); model.updateCurrentConfig(config);
        binding.setModel(model); binding.executePendingBindings();
        BottomBar bar = binding.mainBottomBar;
        int[] callback = {-1};
        bar.setOnItemSelectListener((index,caption,unchanged) -> callback[0]=index);
        bar.setSelection(2);
        assertEquals(2,bar.getSelection()); assertEquals(2,callback[0]);
        assertEquals("工作台",bar.getCurrentCaption().toString());
        bar.setSelection(0);
        render(binding.getRoot(),"main-light");
        assertTrue(bar.getHeight()>0); assertTrue(bar.getBottom()<=2340);
        MainPanel panel = binding.mainPanel;
        panel.setSlideEnabled(true); panel.openPanel(); assertTrue(panel.isOpen());
        shadowOf(android.os.Looper.getMainLooper()).idleFor(Duration.ofMillis(300));
        assertEquals(View.VISIBLE,binding.llCurtain.getVisibility());
        binding.mask.performClick(); assertFalse(panel.isOpen());
        shadowOf(android.os.Looper.getMainLooper()).idleFor(Duration.ofMillis(300));
        assertEquals(View.GONE,binding.llCurtain.getVisibility());
    }
    @Test public void primaryScreensInflateInBothThemes() throws Exception {
        for (String theme : new String[]{"light","dark"}) {
            RuntimeEnvironment.setQualifiers("zh-rCN-w360dp-h780dp"+(theme.equals("dark")?"-night":"-notnight")+"-xxhdpi");
            AppCompatActivity activity = host();
            for (int id : new int[]{R.layout.fragment_mine,R.layout.fragment_stats,R.layout.activity_message,R.layout.fragment_filter}) {
                ViewDataBinding binding = DataBindingUtil.inflate(LayoutInflater.from(activity),id,null,false);
                binding.executePendingBindings();
                render(binding.getRoot(),activity.getResources().getResourceEntryName(id)+"-"+theme);
                assertTrue(binding.getRoot().getMeasuredHeight()>0);
            }
            View about = LayoutInflater.from(activity).inflate(R.layout.dialog_about,null,false);
            render(about,"about-"+theme);
        }
    }
}
