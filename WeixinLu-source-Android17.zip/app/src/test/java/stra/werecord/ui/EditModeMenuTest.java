package stra.werecord.ui;

import android.app.Application;
import android.view.Menu;
import android.widget.PopupMenu;
import androidx.appcompat.app.AppCompatActivity;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.Config;
import stra.werecord.R;
import stra.werecord.ui.design.EditModeMenu;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class)
@Config(sdk=35, application=Application.class)
public class EditModeMenuTest {
    private Menu menu(int resource) {
        AppCompatActivity host = Robolectric.buildActivity(AppCompatActivity.class).get();
        host.setTheme(R.style.Base_AppTheme);
        PopupMenu popup = new PopupMenu(host, new android.view.View(host));
        popup.getMenuInflater().inflate(resource, popup.getMenu());
        return popup.getMenu();
    }
    @Test public void viewingStillOffersRawFieldsButNoMessageMutations() {
        Menu menu = menu(R.menu.message);
        EditModeMenu.messages(menu, false, true);
        assertTrue(menu.findItem(R.id.item_check).isVisible());
        assertTrue(menu.findItem(R.id.item_view_image).isVisible());
        assertFalse(EditModeMenu.changesMessage(R.id.item_view_image));
        for (int id : new int[]{R.id.item_edit, R.id.item_delete, R.id.item_add_before,
                R.id.item_add_after, R.id.item_restore}) assertFalse(menu.findItem(id).isVisible());
        EditModeMenu.messages(menu, true, false);
        assertTrue(menu.findItem(R.id.item_edit).isVisible());
        assertFalse(menu.findItem(R.id.item_restore).isVisible());
        EditModeMenu.messages(menu, true, true);
        assertTrue(menu.findItem(R.id.item_restore).isVisible());
    }
    @Test public void conversationViewingOnlyOffersExport() {
        Menu menu = menu(R.menu.chat_options);
        EditModeMenu.conversations(menu, false);
        for (int i=0; i<menu.size(); i++) {
            assertEquals(menu.getItem(i).getItemId()==R.id.item_export_message, menu.getItem(i).isVisible());
        }
        EditModeMenu.conversations(menu, true);
        for (int i=0; i<menu.size(); i++) assertTrue(menu.getItem(i).isVisible());
    }
}
