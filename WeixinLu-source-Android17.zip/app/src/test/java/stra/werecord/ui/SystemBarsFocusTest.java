package stra.werecord.ui;

import android.app.Application;
import android.content.ContextWrapper;
import android.view.View;
import androidx.core.view.WindowCompat;
import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.annotation.Config;
import stra.werecord.App;
import stra.werecord.R;
import stra.werecord.ui.base.BaseActivity;
import stra.werecord.ui.design.StraInsets;
import stra.werecord.util.ActivityUtils;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class)
@Config(sdk=35, application=Application.class)
public class SystemBarsFocusTest {
    public static class HostActivity extends BaseActivity {}

    private void verifyFocus(boolean light) throws Exception {
        Field app=App.class.getDeclaredField("sApplicationContext");
        app.setAccessible(true);
        app.set(null,new WeakReference<>(RuntimeEnvironment.getApplication()));
        var controller=Robolectric.buildActivity(HostActivity.class);
        HostActivity host=controller.get();
        host.setTheme(R.style.Base_AppTheme);
        controller.create().start().resume();
        View decor=host.getWindow().getDecorView();
        ContextWrapper windowContext=new ContextWrapper(RuntimeEnvironment.getApplication());
        Field context=View.class.getDeclaredField("mContext");
        context.setAccessible(true);
        context.set(decor,windowContext);
        assertThrows(IllegalArgumentException.class,()->ActivityUtils.getHostActivity(decor.getContext()));
        View content=new View(windowContext);
        StraInsets.install(host,content);
        for(int i=0;i<3;i++) {
            host.onWindowFocusChanged(false);
            host.onWindowFocusChanged(true);
            var bars=WindowCompat.getInsetsController(host.getWindow(),decor);
            assertEquals(light,bars.isAppearanceLightStatusBars());
            assertEquals(light,bars.isAppearanceLightNavigationBars());
        }
    }

    @Test @Config(qualifiers="notnight")
    public void lightFocusWorksWithNonActivityWindowContext() throws Exception { verifyFocus(true); }

    @Test @Config(qualifiers="night")
    public void darkFocusWorksWithNonActivityWindowContext() throws Exception { verifyFocus(false); }
}
