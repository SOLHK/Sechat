package stra.werecord.ui;
import android.app.Application;
import android.content.Intent;
import android.os.Parcel;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.Config;
import static org.robolectric.Shadows.shadowOf;
import static org.junit.Assert.*;
import stra.werecord.impl.model.account.Contact;
import stra.werecord.impl.model.account.Talker;
import stra.werecord.ui.design.ContactConversation;
import stra.werecord.ui.main.DetailActivity;
import stra.werecord.ui.message.MessageActivity;
@RunWith(RobolectricTestRunner.class)
@Config(sdk=35,application=Application.class)
public class ContactConversationTest {
    @org.junit.Before public void context() throws Exception {
        java.lang.reflect.Field field=stra.werecord.App.class.getDeclaredField("sApplicationContext");field.setAccessible(true);
        field.set(null,new java.lang.ref.WeakReference<>(org.robolectric.RuntimeEnvironment.getApplication()));
    }
    @Test public void ordinaryFriendOpensTypedConversationWithoutEditingOrConversationCache() throws Exception {
        Contact friend=new Contact("wxid_test_contact"); friend.nickname="测试昵称"; friend.alias="test_alias"; friend.remark="测试备注"; friend.type=Contact.Type.FRIEND;
        DetailActivity detail=Robolectric.buildActivity(DetailActivity.class).get();
        java.lang.reflect.Field field=DetailActivity.class.getDeclaredField("mData");field.setAccessible(true);field.set(detail,friend);
        detail.checkMessages(null);
        Intent intent=shadowOf(detail).getNextStartedActivity(); assertNotNull(intent);
        assertEquals(MessageActivity.class.getName(),intent.getComponent().getClassName());
        Talker talker=intent.getParcelableExtra(MessageActivity.EXTRA_TALKER);
        assertNotNull(talker);assertEquals(friend.id,talker.id);assertEquals(friend.remark,talker.remark);
        Parcel parcel=Parcel.obtain();talker.writeToParcel(parcel,0);parcel.setDataPosition(0);
        Talker restored=Talker.CREATOR.createFromParcel(parcel);parcel.recycle();
        assertEquals(friend.id,restored.id);assertEquals(friend.alias,restored.alias);assertEquals(friend.nickname,restored.nickname);
    }
    @Test public void groupsAndExistingConversationKeepTheirIdentity() {
        Contact group=new Contact("test@chatroom");group.type=Contact.Type.JOINED_GROUP;
        assertEquals(group.id,ContactConversation.from(group).id);
        Talker original=new Talker("wxid_test_contact");original.messageCount=42;
        assertSame(original,ContactConversation.from(original));
        try { ContactConversation.from(new Contact(""));fail(); } catch(IllegalArgumentException expected) { assertTrue(expected.getMessage().contains("微信ID")); }
    }
}
