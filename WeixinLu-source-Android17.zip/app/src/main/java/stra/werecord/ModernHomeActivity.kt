package stra.werecord

import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import stra.werecord.ui.outer.InitializationActivity

class ModernHomeActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val scheme = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            dynamicLightColorScheme(this)
        } else {
            lightColorScheme(primary = Color(0xFF176B5B), secondary = Color(0xFF52645E), background = Color(0xFFF5F7F4))
        }
        setContent {
            MaterialTheme(colorScheme = scheme) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    HomeScreen { startActivity(Intent(this, InitializationActivity::class.java)) }
                }
            }
        }
    }
}

@Composable
private fun HomeScreen(openTool: () -> Unit) {
    val context = LocalContext.current
    val wechatVersion = remember {
        runCatching {
            val info = if (Build.VERSION.SDK_INT >= 33) {
                context.packageManager.getPackageInfo("com.tencent.mm", PackageManager.PackageInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION")
                context.packageManager.getPackageInfo("com.tencent.mm", 0)
            }
            "已安装 · ${info.versionName ?: "版本未知"}"
        }.getOrDefault("未检测到微信")
    }
    Column(
        Modifier.fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding() + 18.dp)
            .padding(bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() + 20.dp)
            .padding(horizontal = 22.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(Modifier.background(MaterialTheme.colorScheme.primary, RoundedCornerShape(18.dp)).padding(13.dp)) {
                Text("路", color = MaterialTheme.colorScheme.onPrimary, fontWeight = FontWeight.Bold, fontSize = 22.sp)
            }
            Column {
                Text("微信路", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Text("本机聊天数据工具", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        Card(
            shape = RoundedCornerShape(30.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("设备状态", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                StatusLine("微信", wechatVersion)
                StatusLine("应用", "现代化私用构建 · v2.0")
                StatusLine("系统", "Android ${Build.VERSION.RELEASE} · API ${Build.VERSION.SDK_INT}")
                StatusLine("LSPosed", "未集成 · 此 APK 是 ROOT 应用")
                StatusLine("Hook", "未启用")
            }
        }

        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("本地工具", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
            Text("本机聊天与联系人数据工具，需要 ROOT 授权。", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Button(
                onClick = openTool,
                modifier = Modifier.fillMaxWidth().height(54.dp),
                shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) { Text("打开聊天与联系人工具", fontWeight = FontWeight.SemiBold) }
        }

        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("功能说明", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
            FeatureRow("聊天记录", "本机数据库读取与筛选")
            FeatureRow("联系人", "微信本地联系人与会话信息")
            FeatureRow("导出", "按原项目提供的本地导出工具")
            FeatureRow("数据库编辑", "编辑和删除会写入本机微信数据库；请自行备份")
            FeatureRow("数据编辑", "保留上游本机消息编辑、删除与写回路径")
        }

        Text(
            "个人本机使用。不要把导出或显示内容当作微信服务器原始记录。",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun StatusLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun FeatureRow(title: String, description: String) {
    Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 15.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.background(MaterialTheme.colorScheme.secondaryContainer, CircleShape).padding(6.dp))
            Column(Modifier.padding(start = 12.dp)) {
                Text(title, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(3.dp))
                Text(description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
