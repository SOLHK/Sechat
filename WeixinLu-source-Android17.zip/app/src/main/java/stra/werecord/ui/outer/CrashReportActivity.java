/*
 * Copyright (c) 2021 xjunz. 保留所有权利
 */
package stra.werecord.ui.outer;

import android.content.Intent;
import android.content.ActivityNotFoundException;
import android.net.Uri;
import android.os.Bundle;
import android.text.format.Formatter;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import androidx.databinding.DataBindingUtil;

import java.io.File;

import stra.werecord.BuildConfig;
import stra.werecord.R;
import stra.werecord.databinding.ActivityCrashReportBinding;
import stra.werecord.util.IoUtils;

/**
 * @author xjunz 2021/2/20 19:44
 */
public class CrashReportActivity extends AppCompatActivity {
    public static final String EXTRA_LOG_FILE_PATH = "CrashReportActivity.extra.LogFilePath";
    public static final String EXTRA_USER_DEBUGGABLE = "CrashReportActivity.extra.UserDebuggable";
    private File mLogFile;
    private boolean mShareStarted;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ActivityCrashReportBinding binding = DataBindingUtil.setContentView(this, R.layout.activity_crash_report);
        String logPath = getIntent().getStringExtra(EXTRA_LOG_FILE_PATH);
        if (logPath == null) {
            binding.setFileSize(getText(R.string.not_found));
        } else {
            mLogFile = new File(logPath);
            if (!mLogFile.exists()) {
                binding.setFileSize(getText(R.string.not_found));
            } else {
                binding.setFileSize(Formatter.formatFileSize(this, mLogFile.length()));
            }
        }
    }

    public void restart(View view) {
        Intent intent = new Intent(this, InitializationActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }

    public void quit(View view) {
        this.finishAndRemoveTask();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (!mShareStarted && mLogFile != null && mLogFile.exists()) {
            IoUtils.deleteFileSync(mLogFile);
        }
    }

    public void send(View view) {
        if (mLogFile == null || !mLogFile.isFile()) {
            stra.werecord.ui.customview.MasterToast.shortToast(R.string.not_found);
            return;
        }
        try {
            Uri uri = FileProvider.getUriForFile(this, BuildConfig.APPLICATION_ID + ".private.fileprovider", mLogFile);
            Intent intent = new Intent(Intent.ACTION_SEND)
                    .setType("text/plain")
                    .putExtra(Intent.EXTRA_SUBJECT, getString(R.string.crash_log))
                    .putExtra(Intent.EXTRA_TEXT, getString(R.string.crash_log_share_text))
                    .putExtra(Intent.EXTRA_STREAM, uri)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            mShareStarted = true;
            startActivity(Intent.createChooser(intent, getString(R.string.share_crash_log)));
        } catch (ActivityNotFoundException | IllegalArgumentException e) {
            mShareStarted = false;
            stra.werecord.ui.customview.MasterToast.shortToast(R.string.operation_failed);
        }
    }

    public void joinFeedbackGroup(View view) {
        send(view);
    }
}
