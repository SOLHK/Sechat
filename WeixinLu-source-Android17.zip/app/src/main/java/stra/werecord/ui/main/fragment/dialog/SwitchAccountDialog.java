package stra.werecord.ui.main.fragment.dialog;

import android.app.Dialog;
import android.os.Bundle;
import android.text.TextUtils;
import androidx.annotation.NonNull;
import androidx.fragment.app.DialogFragment;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import java.util.List;
import stra.werecord.App;
import stra.werecord.impl.Environment;
import stra.werecord.impl.model.account.User;
import stra.werecord.ui.main.MainActivity;
import stra.werecord.util.UiUtils;

/** Switches this reader's database; it does not log WeChat in or out. */
public class SwitchAccountDialog extends DialogFragment {
    @NonNull @Override public Dialog onCreateDialog(Bundle state) {
        List<User> users=Environment.getInstance().getUserList();
        String[] names=new String[users.size()];int checked=-1;
        for(int i=0;i<users.size();i++) {
            User user=users.get(i);
            names[i]=(TextUtils.isEmpty(user.nickname)?"微信账号":user.nickname)+"\n"
                    +(TextUtils.isEmpty(user.id)?"UIN："+user.uin:user.getDisplayWechatNumber());
            if(user.isCurrentUsed) checked=i;
        }
        return new MaterialAlertDialogBuilder(requireContext()).setTitle("切换读取的微信账号")
                .setSingleChoiceItems(names,checked,(dialog,index)-> {
                    User selected=users.get(index);
                    if(selected.isCurrentUsed) return;
                    UiUtils.createAlert(requireContext(),"切换到 "+names[index]+"？当前未应用的修改将丢弃，只切换微信路读取的数据库。")
                            .setPositiveButton(android.R.string.ok,(d,w)-> {
                                App.config().lastUsedUin.setValue(selected.uin);
                                ((MainActivity)requireActivity()).restartWithoutVerification();
                            }).setNegativeButton(android.R.string.cancel,null).show();
                }).setPositiveButton("重新扫描",(d,w)->((MainActivity)requireActivity()).restartWithoutVerification())
                .setNegativeButton("关闭",null).create();
    }
}
