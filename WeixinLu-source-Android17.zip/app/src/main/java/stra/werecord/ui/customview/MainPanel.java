package stra.werecord.ui.customview;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.RelativeLayout;
import android.view.animation.DecelerateInterpolator;
import androidx.annotation.NonNull;
import java.util.ArrayList;
import stra.werecord.R;

/** Modal filtering sheet. Keeps navigation and the current list in place. */
public class MainPanel extends RelativeLayout {
    private final ArrayList<OnPanelSlideListener> listeners = new ArrayList<>();
    private View sheet, scrim;
    private boolean open, enabled;
    private long transition;
    public MainPanel(Context context) { super(context); }
    public MainPanel(Context context, AttributeSet attrs) { super(context, attrs); }
    public MainPanel(Context context, AttributeSet attrs, int style) { super(context, attrs, style); }
    @Override protected void onFinishInflate() {
        super.onFinishInflate();
        sheet = findViewById(R.id.ll_curtain);
        scrim = findViewById(R.id.mask);
        scrim.setOnClickListener(v -> closePanel());
    }
    public void addOnPanelSlideListener(@NonNull OnPanelSlideListener listener) { listeners.add(listener); }
    public void removeOnPanelSlideListener(@NonNull OnPanelSlideListener listener) { listeners.remove(listener); }
    public boolean isSlideEnabled() { return enabled; }
    public void setSlideEnabled(boolean value) { enabled = value; }
    public boolean isOpen() { return open; }
    public void openPanel() { if (enabled) transitionTo(true); }
    public void closePanel() { transitionTo(false); }
    private void transitionTo(boolean target) {
        if (open == target || sheet == null) return;
        open = target;
        long token = ++transition;
        sheet.animate().cancel(); scrim.animate().cancel();
        for (OnPanelSlideListener listener : new ArrayList<>(listeners)) listener.onPanelSlideStart(target);
        sheet.setVisibility(VISIBLE); scrim.setVisibility(VISIBLE);
        if (target) { sheet.setTranslationY(48 * getResources().getDisplayMetrics().density); sheet.setAlpha(0); scrim.setAlpha(0); }
        scrim.animate().alpha(target ? 1 : 0).setDuration(180).start();
        sheet.animate().translationY(target ? 0 : 48 * getResources().getDisplayMetrics().density)
                .alpha(target ? 1 : 0).setDuration(220).setInterpolator(new DecelerateInterpolator())
                .withEndAction(() -> {
                    if (transition != token) return;
                    if (!target) { sheet.setVisibility(GONE); scrim.setVisibility(GONE); }
                    for (OnPanelSlideListener listener : new ArrayList<>(listeners)) {
                        listener.onPanelSlide(target ? 1 : 0);
                        listener.onPanelSlideFinished(target);
                    }
                }).start();
    }
    public interface OnPanelSlideListener {
        void onPanelSlideFinished(boolean isOpen);
        void onPanelSlide(float fraction);
        void onPanelSlideStart(boolean isToOpen);
    }
}
