/*
 * Copyright (c) 2021 xjunz. 保留所有权利
 */
package stra.werecord.ui.message.fragment;

import android.annotation.SuppressLint;
import android.app.ActivityOptions;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.PopupMenu;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.view.OneShotPreDrawListener;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import stra.werecord.R;
import stra.werecord.databinding.FragmentStatsBinding;
import stra.werecord.databinding.ItemChartMsgCountBinding;
import stra.werecord.databinding.ItemChartMsgCountCollapsedBinding;
import stra.werecord.databinding.ItemChartMsgTypeBinding;
import stra.werecord.impl.model.account.Account;
import stra.werecord.impl.model.account.Group;
import stra.werecord.impl.model.message.MessageFactory;
import stra.werecord.impl.repo.ContactRepository;
import stra.werecord.impl.repo.GroupRepository;
import stra.werecord.impl.repo.MessageRepository;
import stra.werecord.impl.repo.RepositoryFactory;
import stra.werecord.ui.main.DetailActivity;
import stra.werecord.ui.message.MessageActivity;
import stra.werecord.ui.viewmodel.MessageViewModel;
import stra.werecord.util.RxJavaUtils;
import stra.werecord.util.UiUtils;
import stra.werecord.util.Utils;

public class StatisticsFragment extends Fragment {
    private MessageViewModel mModel;
    private FragmentStatsBinding mBinding;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mModel = Utils.getViewModel(requireActivity(), MessageViewModel.class);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        mBinding = FragmentStatsBinding.inflate(inflater);
        mBinding.setHost(this);
        return mBinding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        //xml中设置minimumHeight:match_parent不生效，那么我们手动让Container填满NestedScrollView
        OneShotPreDrawListener.add(mBinding.nsvStats, () -> mBinding.statsContainer.setMinimumHeight(mBinding.nsvStats.getHeight()));
    }

    public void startAnalyze(@NotNull View view) {
        Button button = (Button) view;
        button.setEnabled(false);
        button.setText(R.string.loading);
        mBinding.tvScanStatus.setText("正在汇总本地记录，数据较多时请稍候");
        RxJavaUtils.single(this::collectStatistics).subscribe(new RxJavaUtils.SingleObserverAdapter<StatsSummary>() {
            @Override
            public void onSuccess(@NotNull StatsSummary summary) {
                if (!isAdded() || mBinding == null) return;
                button.setEnabled(true);
                button.setText(R.string.check_stats);
                showStatistics(summary);
                mBinding.tvScanStatus.setText("概览已更新");
            }

            @Override
            public void onError(@NotNull Throwable error) {
                if (isAdded() && mBinding != null) {
                    button.setEnabled(true);
                    button.setText(R.string.check_stats);
                    android.util.Log.e("WeixinLuStatistics", "Statistics query failed", error);
                    String details = stra.werecord.util.IoUtils.readStackTraceFromThrowable(error);
                    UiUtils.createDialog(requireContext(), R.string.operation_failed, details)
                            .setPositiveButton(android.R.string.ok, null)
                            .setNeutralButton(R.string.copy, (dialog, which) ->
                                    Utils.copyPlainText("WeixinLu statistics error", details))
                            .show();
                }
            }
        });
    }

    /** SQLite performs the full-history scan and returns compact grouped counters. */
    @NonNull
    private StatsSummary collectStatistics() {
        MessageRepository repository = RepositoryFactory.get(MessageRepository.class);
        String talkerId = mModel.currentTalker.id;
        stra.werecord.impl.model.account.User currentUser =
                stra.werecord.impl.Environment.getInstance().getCurrentUser();
        String currentUserId = currentUser == null ? null : currentUser.id;
        Map<String, Long> senderCounts = new HashMap<>();
        Map<MessageFactory.Type, Long> typeCounts = new HashMap<>();
        long messageCount = 0;
        long oldestTimestamp = Long.MAX_VALUE;
        long newestTimestamp = Long.MIN_VALUE;
        long systemMessageCount = 0;
        for (MessageRepository.StatisticsAggregate aggregate : repository.queryStatisticsAggregates(talkerId, currentUserId)) {
            messageCount += aggregate.count;
            oldestTimestamp = Math.min(oldestTimestamp, aggregate.oldestTimestamp);
            newestTimestamp = Math.max(newestTimestamp, aggregate.newestTimestamp);
            MessageFactory.Type type = MessageFactory.getTypeFromRaw(aggregate.rawType);
            typeCounts.put(type, typeCounts.getOrDefault(type, 0L) + aggregate.count);
            if (aggregate.senderId == null) {
                systemMessageCount += aggregate.count;
            } else {
                senderCounts.put(aggregate.senderId,
                        senderCounts.getOrDefault(aggregate.senderId, 0L) + aggregate.count);
            }
        }

        List<MsgCountStat> senderStats = new ArrayList<>(senderCounts.size());
        for (Map.Entry<String, Long> entry : senderCounts.entrySet()) {
            MsgCountStat stat = new MsgCountStat(entry.getKey());
            stat.count = (int) Math.min(Integer.MAX_VALUE, entry.getValue());
            senderStats.add(stat);
        }
        List<MsgTypeStat> typeStats = new ArrayList<>(typeCounts.size());
        for (Map.Entry<MessageFactory.Type, Long> entry : typeCounts.entrySet()) {
            MsgTypeStat stat = new MsgTypeStat(entry.getKey());
            stat.count = (int) Math.min(Integer.MAX_VALUE, entry.getValue());
            typeStats.add(stat);
        }
        Collections.sort(senderStats);
        Collections.sort(typeStats);
        int userMessageCount = (int) Math.min(Integer.MAX_VALUE, Math.max(0, messageCount - systemMessageCount));
        MsgCountStat.totalCount = userMessageCount;
        MsgTypeStat.totalCount = (int) Math.min(Integer.MAX_VALUE, messageCount);

        int showCount = 0;
        float fractionSum = 0f;
        for (int i = 0; i < senderStats.size(); i++) {
            fractionSum += senderStats.get(i).getFraction();
            if (fractionSum >= .75f) {
                showCount = i + 1;
                break;
            }
        }
        showCount = Math.min(senderStats.size(), Math.max(5, Math.min(showCount, 10)));
        if (showCount != senderStats.size() && senderStats.size() - showCount < 3) {
            showCount = senderStats.size() - 3;
        }

        if (messageCount == 0) {
            oldestTimestamp = 0;
            newestTimestamp = 0;
        }
        return new StatsSummary(senderStats, typeStats, userMessageCount, showCount,
                messageCount, oldestTimestamp, newestTimestamp);
    }

    private void showStatistics(@NonNull StatsSummary summary) {
        UiUtils.fadeOut(mBinding.mask);
        if (mModel.currentTalker.isGroup()) {
            Group group = RepositoryFactory.get(GroupRepository.class).get(mModel.currentTalker.id);
            int memberCount = group == null ? 0 : group.memberCount;
            mBinding.tvOverview.setText(getString(R.string.format_group_stats_overview,
                    summary.userMessageCount, memberCount, summary.senderStats.size()));
        } else {
            mBinding.tvOverview.setText(getString(R.string.format_stats_overview, summary.userMessageCount));
        }
        if (summary.messageCount == 0) {
            mBinding.tvTimeSpan.setText(R.string.not_found);
        } else {
            mBinding.tvTimeSpan.setText(getString(R.string.format_from_to,
                    Utils.formatDate(summary.oldestTimestamp), Utils.formatDate(summary.newestTimestamp)));
        }
        mBinding.rvStatsMsgCount.setAdapter(new MsgStatAdapter(summary.senderStats, summary.senderShowCount, true));
        mBinding.rvStatsMsgType.setAdapter(new MsgStatAdapter(summary.typeStats, (int) Math.min(Integer.MAX_VALUE, summary.messageCount), false));
    }

    private static final class StatsSummary {
        final List<MsgCountStat> senderStats;
        final List<MsgTypeStat> typeStats;
        final int userMessageCount;
        final int senderShowCount;
        final long messageCount;
        final long oldestTimestamp;
        final long newestTimestamp;

        StatsSummary(List<MsgCountStat> senderStats, List<MsgTypeStat> typeStats, int userMessageCount,
                     int senderShowCount, long messageCount, long oldestTimestamp, long newestTimestamp) {
            this.senderStats = senderStats;
            this.typeStats = typeStats;
            this.userMessageCount = userMessageCount;
            this.senderShowCount = senderShowCount;
            this.messageCount = messageCount;
            this.oldestTimestamp = oldestTimestamp;
            this.newestTimestamp = newestTimestamp;
        }
    }

    public void showCollapsedSenders(View view, @NotNull List<?> list) {
        PopupMenu menu = new PopupMenu(requireContext(), view);
        for (int i = 0; i < list.size(); i++) {
            MsgCountStat stat = (MsgCountStat) list.get(i);
            Account account = stat.getSender();
            menu.getMenu().add(0, i, 0, stat.getName() + String.format(" (%s)", getString(R.string.format_msg_count, stat.count)));
        }
        menu.setOnMenuItemClickListener(item -> {
            if (((MsgCountStat) list.get(item.getItemId())).getSender() == null) return true;
            Intent intent = new Intent(requireActivity(), DetailActivity.class);
            intent.putExtra(DetailActivity.EXTRA_CONTACT_ID, ((MsgCountStat) list.get(item.getItemId())).sender);
            startActivity(intent, ActivityOptions.makeSceneTransitionAnimation(requireActivity()).toBundle());
            return true;
        });
        menu.setGravity(Gravity.END);
        menu.show();
    }

    public void showSenderDetail(@NotNull MsgStat stat, View sharedElement) {
        if (((MsgCountStat) stat).getSender() == null) return;
        Intent intent = new Intent(requireActivity(), DetailActivity.class);
        intent.putExtra(DetailActivity.EXTRA_CONTACT_ID, ((MsgCountStat) stat).sender);
        startActivity(intent, ActivityOptions.makeSceneTransitionAnimation(requireActivity(), sharedElement, sharedElement.getTransitionName()).toBundle());
    }

    public static abstract class MsgStat implements Comparable<MsgStat> {
        public int count = 1;

        public void increment() {
            count += 1;
        }

        public abstract String getName();

        protected abstract int getTotalCount();

        public float getFraction() {
            return getTotalCount() <= 0 ? 0f : (float) count / getTotalCount();
        }

        @SuppressLint("DefaultLocale")
        public String getPercentage() {
            return String.format("%.2f%%", getFraction() * 100);
        }

        @Override
        public int compareTo(@NotNull MsgStat o) {
            //降序，加负号
            return -Integer.compare(this.count, o.count);
        }
    }

    public static class MsgCountStat extends MsgStat {
        private final String sender;
        private static int totalCount;

        public MsgCountStat(String sender) {
            this.sender = sender;
        }

        public Account getSender() {
            if (MessageRepository.STATISTICS_SELF.equals(sender)) return null;
            return RepositoryFactory.get(ContactRepository.class).get(sender);
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            MsgCountStat stat = (MsgCountStat) o;
            return Objects.equals(sender, stat.sender);
        }

        @Override
        public int hashCode() {
            return Objects.hash(sender);
        }


        @Override
        public String getName() {
            if (MessageRepository.STATISTICS_SELF.equals(sender)) return "我";
            Account account = getSender();
            return account == null ? sender : account.getName();
        }

        @Override
        protected int getTotalCount() {
            return totalCount;
        }
    }

    public static class MsgTypeStat extends MsgStat {
        public MessageFactory.Type type;
        private static int totalCount;

        public MsgTypeStat(MessageFactory.Type type) {
            this.type = type;
        }

        @Override
        public String getName() {
            return type.getCaption();
        }

        @Override
        protected int getTotalCount() {
            return totalCount;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            MsgTypeStat stat = (MsgTypeStat) o;
            return Objects.equals(type, stat.type);
        }

        @Override
        public int hashCode() {
            return Objects.hash(type);
        }
    }

    private class MsgStatAdapter extends RecyclerView.Adapter<MsgStatAdapter.MsgStatViewHolder> {
        private final List<? extends MsgStat> mStats;
        private final int mShowCount;
        private final boolean mCollapsed;
        private final boolean mIsMsgCountChart;
        private final int TYPE_NORMAL = 0;
        private final int TYPE_COLLAPSED = 1;

        @Override
        public int getItemViewType(int position) {
            return mCollapsed && position == mShowCount ? TYPE_COLLAPSED : TYPE_NORMAL;
        }

        private MsgStatAdapter(List<? extends MsgStat> stats, int showCount, boolean count) {
            mStats = stats;
            mShowCount = showCount;
            mCollapsed = mShowCount < mStats.size();
            mIsMsgCountChart = count;
        }

        @NonNull
        @Override
        public MsgStatViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            if (viewType == TYPE_COLLAPSED) {
                return new MsgStatViewHolder((ItemChartMsgCountCollapsedBinding) DataBindingUtil.inflate(getLayoutInflater(), R.layout.item_chart_msg_count_collapsed, parent, false));
            } else {
                if (mIsMsgCountChart) {
                    return new MsgStatViewHolder((ItemChartMsgCountBinding) DataBindingUtil.inflate(getLayoutInflater(), R.layout.item_chart_msg_count, parent, false));
                } else {
                    return new MsgStatViewHolder((ItemChartMsgTypeBinding) DataBindingUtil.inflate(getLayoutInflater(), R.layout.item_chart_msg_type, parent, false));
                }
            }
        }

        @Override
        public void onBindViewHolder(@NonNull MsgStatViewHolder holder, int position) {
            if (getItemViewType(position) == TYPE_NORMAL) {
                MsgStat stat = mStats.get(position);
                if (mIsMsgCountChart) {
                    holder.msgCountBinding.setStat((MsgCountStat) stat);
                    holder.msgCountBinding.chartBar.animateProgress();
                    holder.msgCountBinding.executePendingBindings();
                } else {
                    holder.msgTypeBinding.setStat(stat);
                    holder.msgTypeBinding.chartBar.animateProgress();
                    holder.msgTypeBinding.executePendingBindings();
                }
            } else {
                holder.collapsedBinding.setCollapsedStats(mStats.subList(mShowCount, mStats.size()));
                holder.collapsedBinding.executePendingBindings();
            }
        }

        @Override
        public int getItemCount() {
            return mCollapsed ? mShowCount + 1 : mStats.size();
        }

        private class MsgStatViewHolder extends RecyclerView.ViewHolder {
            ItemChartMsgCountBinding msgCountBinding;
            ItemChartMsgTypeBinding msgTypeBinding;
            ItemChartMsgCountCollapsedBinding collapsedBinding;

            public MsgStatViewHolder(@NonNull ItemChartMsgCountBinding binding) {
                super(binding.getRoot());
                this.msgCountBinding = binding;
                this.msgCountBinding.setHost(StatisticsFragment.this);
            }

            public MsgStatViewHolder(@NonNull ItemChartMsgCountCollapsedBinding binding) {
                super(binding.getRoot());
                this.collapsedBinding = binding;
                this.collapsedBinding.setHost(StatisticsFragment.this);
            }

            public MsgStatViewHolder(@NonNull ItemChartMsgTypeBinding binding) {
                super(binding.getRoot());
                this.msgTypeBinding = binding;
            }
        }
    }
}
