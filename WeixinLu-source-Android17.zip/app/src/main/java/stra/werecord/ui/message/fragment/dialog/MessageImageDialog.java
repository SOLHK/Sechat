package stra.werecord.ui.message.fragment.dialog;

import android.app.Dialog;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.annotation.NonNull;
import androidx.fragment.app.DialogFragment;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import io.reactivex.disposables.Disposable;
import stra.werecord.impl.media.MessageImageLoader;
import stra.werecord.impl.model.message.Message;
import stra.werecord.ui.customview.ZoomImageView;
import stra.werecord.util.RxJavaUtils;
import stra.werecord.util.UiUtils;

public class MessageImageDialog extends DialogFragment {
    private Disposable loading;
    private Bitmap bitmap;
    private ZoomImageView image;
    public static MessageImageDialog forMessage(Message message) {
        MessageImageDialog dialog=new MessageImageDialog();Bundle args=new Bundle();args.putParcelable("message",message);dialog.setArguments(args);return dialog;
    }
    @NonNull @Override public Dialog onCreateDialog(Bundle state) {
        LinearLayout content=new LinearLayout(requireContext());content.setOrientation(LinearLayout.VERTICAL);
        int padding=Math.round(16*getResources().getDisplayMetrics().density);content.setPadding(padding,0,padding,padding);
        ProgressBar progress=new ProgressBar(requireContext());content.addView(progress,new LinearLayout.LayoutParams(-1,padding*3));
        image=new ZoomImageView(requireContext());content.addView(image,new LinearLayout.LayoutParams(-1,(int)(getResources().getDisplayMetrics().heightPixels*.6f)));
        TextView info=new TextView(requireContext());info.setText("读取本地图片…");info.setPadding(0,padding,0,0);content.addView(info);
        Message message=requireArguments().getParcelable("message");
        loading=RxJavaUtils.single(()->MessageImageLoader.load(message)).subscribe(value->{
            bitmap=value;image.setImageBitmap(value);progress.setVisibility(View.GONE);info.setText("双指缩放 / 双击放大。本地缓存可能只有缩略图。");
        },error->{
            progress.setVisibility(View.GONE);image.setVisibility(View.GONE);info.setText("图片读取失败，可复制详细异常定位。");
            info.setOnClickListener(v->UiUtils.showError(requireContext(),error));
            if(isAdded()) UiUtils.showError(requireContext(),error);
        });
        return new MaterialAlertDialogBuilder(requireContext()).setTitle("查看图片").setView(content).setPositiveButton("关闭",null).create();
    }
    @Override public void onDestroyView() {
        if(loading!=null) loading.dispose();
        if(image!=null) image.setImageDrawable(null);
        if(bitmap!=null) { bitmap.recycle();bitmap=null; }
        super.onDestroyView();
    }
}
