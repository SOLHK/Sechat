package stra.werecord.ui.customview;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import androidx.annotation.Nullable;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;
import stra.werecord.R;

/** STRA navigation: labeled destinations with Material active indicators. */
public class BottomBar extends BottomNavigationView {
    private CharSequence[] captions = new CharSequence[0];
    private OnItemSelectListener listener;
    private int selection = -1;

    public BottomBar(Context context) { this(context, null); }
    public BottomBar(Context context, @Nullable AttributeSet attrs) { this(context, attrs, 0); }
    public BottomBar(Context context, @Nullable AttributeSet attrs, int style) {
        super(context, attrs, style);
        setLabelVisibilityMode(NavigationBarView.LABEL_VISIBILITY_LABELED);
        setItemHorizontalTranslationEnabled(false);
        setItemIconSize(dp(24));
        setItemActiveIndicatorEnabled(true);
        setItemActiveIndicatorWidth(dp(64));
        setItemActiveIndicatorHeight(dp(32));
        setItemActiveIndicatorColor(android.content.res.ColorStateList.valueOf(
                androidx.core.content.ContextCompat.getColor(context, R.color.stra_strong)));
        setItemActiveIndicatorShapeAppearance(com.google.android.material.shape.ShapeAppearanceModel.builder()
                .setAllCornerSizes(dp(20)).build());
        TypedArray config = context.obtainStyledAttributes(attrs, R.styleable.BottomBar);
        int images = config.getResourceId(R.styleable.BottomBar_imageEntries, 0);
        CharSequence[] labels = config.getTextArray(R.styleable.BottomBar_captionEntries);
        config.recycle();
        if (labels != null) captions = labels;
        if (images != 0) {
            TypedArray icons = getResources().obtainTypedArray(images);
            for (int i = 0; i < captions.length; i++) {
                getMenu().add(0, i + 1, i, captions[i]).setIcon(icons.getResourceId(i, 0));
            }
            icons.recycle();
        }
        setOnItemSelectedListener(item -> { dispatch(item.getItemId() - 1); return true; });
        setOnItemReselectedListener(item -> dispatch(item.getItemId() - 1));
    }
    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }
    private void dispatch(int index) {
        if (index < 0 || index >= captions.length) return;
        boolean unchanged = selection == index;
        selection = index;
        if (listener != null) listener.onItemSelect(index, captions[index], unchanged);
    }
    public void setSelection(int index) {
        if (index < 0 || index >= captions.length) return;
        if (selection != index) {
            setSelectedItemId(index + 1);
            if (selection != index) dispatch(index);
        }
    }
    public int getSelection() { return selection; }
    public CharSequence getCurrentCaption() { return selection < 0 ? "" : captions[selection]; }
    public void setOnItemSelectListener(@Nullable OnItemSelectListener value) { listener = value; }
    public interface OnItemSelectListener { void onItemSelect(int position, CharSequence caption, boolean unchanged); }
}
