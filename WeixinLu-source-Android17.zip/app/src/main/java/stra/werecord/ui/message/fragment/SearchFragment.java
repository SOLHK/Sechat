/*
 * Copyright (c) 2021 xjunz. 保留所有权利
 */
package stra.werecord.ui.message.fragment;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.RecyclerView;

import org.reactivestreams.Publisher;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.BackpressureStrategy;
import io.reactivex.Flowable;
import io.reactivex.FlowableOnSubscribe;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Function;
import io.reactivex.schedulers.Schedulers;
import stra.werecord.R;
import stra.werecord.databinding.FragmentSearchBinding;
import stra.werecord.databinding.ItemMessageSearchResultBinding;
import stra.werecord.impl.model.message.Message;
import stra.werecord.ui.message.MessageActivity;
import stra.werecord.ui.viewmodel.MessageViewModel;
import stra.werecord.util.UiUtils;

/**
 * 承载消息搜索功能和显示搜索结果的{@link Fragment}
 */
public class SearchFragment extends Fragment implements MessageViewModel.SearchDelegate {
    /**
     * 当前搜索结果
     */
    private final List<MessageItem> mSearchResult = new ArrayList<>();
    private Disposable mSearchDisposable;
    private MessageViewModel mModel;
    private FragmentSearchBinding mBinding;
    private MessageResultAdapter mAdapter;
    private MessageActivity mHost;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mModel = new ViewModelProvider(requireActivity(), new ViewModelProvider.NewInstanceFactory()).get(MessageViewModel.class);
        mModel.delegateSearch(this);
        mHost = (MessageActivity) requireActivity();
    }


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        mBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_search, container, false);
        return mBinding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mAdapter=new MessageResultAdapter(); mBinding.rvResult.setAdapter(mAdapter);
        mBinding.btnNext.setOnClickListener(v -> {
            if(mLoading) return;
            mPageStarts.add(new long[]{mBeforeTime,mBeforeId}); loadPage(mBeforeTime,mBeforeId);
        });
        mBinding.btnPrevious.setOnClickListener(v -> {
            if(mLoading || mPageStarts.size()<2) return;
            mPageStarts.remove(mPageStarts.size()-1);
            long[] start=mPageStarts.get(mPageStarts.size()-1); loadPage(start[0],start[1]);
        });
        search(mKeyword);
    }

    private String mKeyword="";
    private long mBeforeTime=Long.MAX_VALUE,mBeforeId=Long.MAX_VALUE;
    private volatile long mGeneration;
    private boolean mLoading;
    private final java.util.ArrayList<long[]> mPageStarts=new java.util.ArrayList<>();

    @Override public void search(String keyword) {
        if(mBinding==null) { mKeyword=keyword; return; }
        mKeyword=keyword;
        mPageStarts.clear(); mPageStarts.add(new long[]{Long.MAX_VALUE,Long.MAX_VALUE});
        loadPage(Long.MAX_VALUE,Long.MAX_VALUE);
    }

    private void loadPage(long time,long id) {
        long generation=++mGeneration;
        if(mSearchDisposable!=null) mSearchDisposable.dispose();
        mSearchResult.clear();
        mAdapter.notifyDataSetChanged();
        mBinding.btnNext.setEnabled(false); mBinding.btnPrevious.setEnabled(false);
        if(TextUtils.isEmpty(mKeyword)) {
            mLoading=false; mBinding.pbLoad.setVisibility(View.GONE);
            mBinding.ivNoResult.setVisibility(View.VISIBLE); return;
        }
        mLoading=true;
        mBinding.pbLoad.setVisibility(View.VISIBLE);
        mBinding.ivNoResult.setVisibility(View.GONE);
        final String keyword=mKeyword;
        mSearchDisposable=io.reactivex.Single.timer(300,java.util.concurrent.TimeUnit.MILLISECONDS)
                .flatMap(ignored -> io.reactivex.Single.fromCallable(() -> {
            SearchPage result=new SearchPage();
            long beforeTime=time,beforeId=id;
            while(result.items.size()<stra.werecord.impl.repo.MessageSearchQuery.PAGE_SIZE && generation==mGeneration) {
                List<Message> candidates=stra.werecord.impl.repo.RepositoryFactory.get(stra.werecord.impl.repo.MessageRepository.class)
                    .searchPage(mModel.currentTalker.id,keyword,beforeTime,beforeId);
                if(candidates.isEmpty()) { result.end=true; break; }
                for(Message message:candidates) {
                    beforeTime=message.getCreateTimeStamp(); beforeId=message.getMsgId();
                    String content=message.getParsedContent();
                    int index=content==null ? -1 : content.indexOf(keyword);
                    if(index>=0) {
                        MessageItem item=new MessageItem(message); item.spanStartIndex=index; item.spanLength=keyword.length();
                        result.items.add(item);
                    }
                    if(result.items.size()==stra.werecord.impl.repo.MessageSearchQuery.PAGE_SIZE) break;
                }
                if(candidates.size()<stra.werecord.impl.repo.MessageSearchQuery.PAGE_SIZE && result.items.size()<stra.werecord.impl.repo.MessageSearchQuery.PAGE_SIZE) { result.end=true; break; }
            }
            result.time=beforeTime; result.id=beforeId; return result;
        })).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).subscribe(page -> {
            if(generation!=mGeneration || mBinding==null) return;
            mLoading=false; mSearchResult.addAll(page.items); mAdapter.notifyDataSetChanged();
            mBinding.rvResult.scrollToPosition(0);
            mBeforeTime=page.time; mBeforeId=page.id;
            mBinding.ivNoResult.setVisibility(page.items.isEmpty()?View.VISIBLE:View.GONE);
            mBinding.pbLoad.setVisibility(View.GONE);
            mBinding.btnNext.setEnabled(!page.end && !page.items.isEmpty());
            mBinding.btnPrevious.setEnabled(mPageStarts.size()>1);
        },error -> {
            if(generation!=mGeneration || mBinding==null) return;
            mLoading=false; mBinding.pbLoad.setVisibility(View.GONE);
            mBinding.btnPrevious.setEnabled(mPageStarts.size()>1);
            if(isAdded()) UiUtils.showError(requireContext(),error);
        });
    }

    private static class SearchPage {
        final List<MessageItem> items=new ArrayList<>();
        long time,id; boolean end;
    }

    /**
     * 用于显示搜索结果的的数据项实体类，包装了{@link Message}和搜索
     * 关键字的所在的索引和长度，用于显示{@link android.text.Spanned}
     */
    public static class MessageItem {
        public Message message;
        public int spanStartIndex, spanLength;

        public MessageItem(Message message) {
            this.message = message;
            this.spanStartIndex = -1;
            this.spanLength = -1;
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        ++mGeneration; mBinding=null;
        if (mSearchDisposable != null && !mSearchDisposable.isDisposed()) {
            mSearchDisposable.dispose();
        }
    }

    private class MessageResultAdapter extends RecyclerView.Adapter<MessageResultViewHolder> {

        @NonNull
        @Override
        public MessageResultViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            ItemMessageSearchResultBinding binding = DataBindingUtil.inflate(getLayoutInflater(), R.layout.item_message_search_result, parent, false);
            return new MessageResultViewHolder(binding);
        }

        @Override
        public void onBindViewHolder(@NonNull MessageResultViewHolder holder, int position) {
            holder.binding.setItem(mSearchResult.get(position));
            holder.binding.executePendingBindings();
        }

        @Override
        public int getItemCount() {
            return mSearchResult.size();
        }
    }

    private class MessageResultViewHolder extends RecyclerView.ViewHolder {
        ItemMessageSearchResultBinding binding;

        public MessageResultViewHolder(@NonNull ItemMessageSearchResultBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
            this.binding.setHost(mHost);
        }
    }
}
