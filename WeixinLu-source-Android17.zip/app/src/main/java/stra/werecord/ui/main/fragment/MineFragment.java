/*
 * Copyright (c) 2021 xjunz. 保留所有权利
 */
package stra.werecord.ui.main.fragment;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.activity.result.ActivityResultLauncher;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;

import com.google.android.gms.oss.licenses.OssLicensesMenuActivity;

import net.sqlcipher.database.SQLiteDatabase;

import org.jetbrains.annotations.NotNull;

import java.io.File;
import java.io.IOException;

import stra.werecord.App;
import stra.werecord.BuildConfig;
import stra.werecord.Constants;
import stra.werecord.R;
import stra.werecord.Settings;
import stra.werecord.databinding.FragmentMineBinding;
import stra.werecord.impl.Environment;
import stra.werecord.impl.model.export.DatabaseExporter;
import stra.werecord.ui.base.ProgressDialog;
import stra.werecord.ui.customview.MasterToast;
import stra.werecord.ui.export.ExportShowcaseDialog;
import stra.werecord.ui.main.fragment.dialog.AboutDialog;
import stra.werecord.ui.main.fragment.dialog.SwitchAccountDialog;
import stra.werecord.ui.viewmodel.PageConfig;
import stra.werecord.util.ActivityUtils;
import stra.werecord.util.IoUtils;
import stra.werecord.util.RxJavaUtils;
import stra.werecord.util.UiUtils;

/**
 * @author xjunz 2021/2/11 12:01
 */
public class MineFragment extends PageFragment {
    private FragmentMineBinding mBinding;
    private Settings mSettings;
    private ActivityResultLauncher<Void> mDeviceCredentialConfirmationLauncher;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        mDeviceCredentialConfirmationLauncher = ActivityUtils.registerDeviceCredentialConfirmationLauncher(this, R.string.verify_owner_title, -1,
                () -> mSettings.verifyDeviceCredential.toggleValue(), () -> MasterToast.shortToast(R.string.unable_to_verify_device_credential));
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mSettings = App.config();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return (mBinding = FragmentMineBinding.inflate(inflater, container, false)).getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mBinding.setUser(Environment.getInstance().getCurrentUser());
        mBinding.setSettings(mSettings);
        mBinding.setHost(this);
    }

    @Override
    public PageConfig getInitialConfig() {
        PageConfig pageConfig = new PageConfig();
        pageConfig.filterEnabled = false;
        pageConfig.caption = App.getStringOf(R.string.mine);
        return pageConfig;
    }

    public void toggleEditMode() {
        if (mSettings.isEditModeEnabled()) {
            mSettings.editMode.toggleValue();
            Environment.getInstance().reopenDatabase(SQLiteDatabase.OPEN_READONLY);
        } else {
            AlertDialog dialog = UiUtils.createCaveat(requireContext(), R.string.warning_edit_mode)
                    .setPositiveButton(android.R.string.ok, (dialog1, which) -> {
                        mSettings.editMode.toggleValue();
                        Environment.getInstance().reopenDatabase(SQLiteDatabase.OPEN_READWRITE);
                    })
                    .setNegativeButton(android.R.string.cancel, null).show();
            Button button = dialog.getButton(DialogInterface.BUTTON_POSITIVE);
            button.setEnabled(false);
            new CountDownTimer(3000L, 1000L) {
                final CharSequence originalText = button.getText();

                @Override
                public void onTick(long millisUntilFinished) {
                    button.setText(String.format("%s (%s)", originalText, millisUntilFinished / 1000 + 1));
                }

                @Override
                public void onFinish() {
                    button.setText(originalText);
                    button.setEnabled(true);
                }
            }.start();
            dialog.show();
        }
    }

    public void showSwitchAccountDialog() {
        new SwitchAccountDialog().show(getParentFragmentManager(), "switch_account");
    }

    public void toggleEnableVerifyDeviceCredential() {
        if (mSettings.isVerifyDeviceCredentialEnabled()) {
            if (mDeviceCredentialConfirmationLauncher != null) {
                mDeviceCredentialConfirmationLauncher.launch(null);
            }
        } else {
            mSettings.verifyDeviceCredential.toggleValue();
        }
    }

    public void showOssLicenses() {
        startActivity(new Intent(requireContext(), OssLicensesMenuActivity.class));
    }

    private void clearExportCacheIfExists(File cache) {
        if (cache != null && cache.exists()) {
            IoUtils.deleteFileSync(cache);
        }
    }

    public void backupOriginalDatabase() {
        ProgressDialog dialog = ProgressDialog.build(requireContext()).setTitle(R.string.exporting);
        try {
            File tempFile = File.createTempFile("backup", null);
            DatabaseExporter exporter = new DatabaseExporter(DatabaseExporter.MODE_KEEP);
            exporter.exportToAsync(tempFile, null)
                    .doOnSubscribe(d -> dialog.setCancelableAction(d::dispose).show())
                    .doFinally(dialog::dismiss)
                    .doOnError(e -> clearExportCacheIfExists(tempFile))
                    .doOnDispose(() -> clearExportCacheIfExists(tempFile))
                    .subscribe(new RxJavaUtils.CompletableObservableAdapter() {
                        @Override
                        public void onError(@NotNull Throwable e) {
                            UiUtils.showError(requireContext(), e);
                        }

                        @Override
                        public void onComplete() {
                            new ExportShowcaseDialog().setFile(tempFile)
                                    .setFilename(exporter.getExportFileName())
                                    .show(getParentFragmentManager(), "backupOriginalDatabase");
                        }
                    });
        } catch (IOException e) {
            MasterToast.shortToast(e.getMessage());
        }
    }

    public void exportDecryptedDatabase() {
        if (!App.config().isEditModeEnabled()) {
            MasterToast.shortToast(R.string.edit_mode_not_enabled);
            return;
        }
        ProgressDialog dialog = ProgressDialog.build(requireContext()).setTitle(R.string.exporting);
        try {
            File tempFile = File.createTempFile("database", null);
            DatabaseExporter exporter = new DatabaseExporter(DatabaseExporter.MODE_DECRYPT);
            exporter.getPasswordConfig().setValue(null);
            exporter.exportToAsync(tempFile, null)
                    .doOnSubscribe(d -> dialog.setCancelableAction(d::dispose).show())
                    .doFinally(dialog::dismiss)
                    .doOnError(e -> clearExportCacheIfExists(tempFile))
                    .doOnDispose(() -> clearExportCacheIfExists(tempFile))
                    .subscribe(new RxJavaUtils.CompletableObservableAdapter() {
                        @Override
                        public void onError(@NotNull Throwable e) {
                            UiUtils.showError(requireContext(), e);
                        }

                        @Override
                        public void onComplete() {
                            new ExportShowcaseDialog().setFile(tempFile)
                                    .setFilename(exporter.getExportFileName())
                                    .show(getParentFragmentManager(), "exportDecryptedDatabase");
                        }
                    });
        } catch (IOException e) {
            MasterToast.shortToast(e.getMessage());
        }
    }

    public void getLatestVersion() {
        MasterToast.longToast(getString(R.string.format_current_app_version, BuildConfig.VERSION_NAME));
        ActivityUtils.safeViewUri(requireContext(), Constants.URL_APP_DOWNLOAD_PAGE);
    }

    public void showAppInfo() {
        new AboutDialog().show(getParentFragmentManager(), "about");
    }

    public void gotoFeedback(View view) {
        ActivityUtils.feedbackAutoFallback(requireContext(), Environment.getBasicEnvInfo()+"\n账户读取：\n"+("微信ID："+Environment.getInstance().getCurrentUser().id+"\n昵称："+Environment.getInstance().getCurrentUser().nickname+"\n微信号："+Environment.getInstance().getCurrentUser().alias+"\n"+Environment.getInstance().getCurrentUser().profileReadError));
    }
}
