package stra.werecord.ui.design;
public final class RecordUi {
    private RecordUi() {}
    private static final ThreadLocal<java.text.SimpleDateFormat> TIME = ThreadLocal.withInitial(
        () -> new java.text.SimpleDateFormat("MM.dd HH:mm", java.util.Locale.CHINA));
    public static String time(long value) { return TIME.get().format(new java.util.Date(value)); }
}
