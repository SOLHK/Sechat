package stra.werecord.ui.main.fragment.dialog;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import stra.werecord.BuildConfig;
import stra.werecord.R;

/** Version sheet. */
public class AboutDialog extends BottomSheetDialogFragment {
    @Nullable @Override public View onCreateView(@NonNull LayoutInflater inflater,
            @Nullable ViewGroup parent, @Nullable Bundle state) {
        View page = inflater.inflate(R.layout.dialog_about, parent, false);
        ((TextView) page.findViewById(R.id.tv_version_name)).setText("微信路 / " + BuildConfig.VERSION_NAME);
        page.findViewById(R.id.btn_close_guide).setOnClickListener(v -> dismiss());
        return page;
    }
}
