package stra.werecord.ui.design;
import stra.werecord.impl.model.account.Contact;
import stra.werecord.impl.model.account.Talker;
/** A contact does not need a visible rconversation row to read its local history. */
public final class ContactConversation {
    public static Talker from(Contact contact) {
        if(contact==null || contact.id==null || contact.id.trim().isEmpty())
            throw new IllegalArgumentException("无法查看消息：联系人微信ID为空");
        if(contact instanceof Talker) return (Talker)contact;
        Talker talker=new Talker(contact.id);
        talker.nickname=contact.nickname;talker.alias=contact.alias;talker.remark=contact.remark;
        talker.rawType=contact.rawType;talker.type=contact.type;
        return talker;
    }
    private ContactConversation() { }
}
