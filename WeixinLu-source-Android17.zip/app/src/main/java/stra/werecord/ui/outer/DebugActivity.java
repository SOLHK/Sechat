package stra.werecord.ui.outer;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import stra.werecord.BuildConfig;

public class DebugActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TextView status = new TextView(this);
        status.setText("微信路个人版\\n" + BuildConfig.VERSION_NAME + "\\n" + BuildConfig.APPLICATION_ID);
        status.setTextSize(16f);
        int padding = (int) (24 * getResources().getDisplayMetrics().density);
        status.setPadding(padding, padding, padding, padding);
        setContentView(status);
    }
}
