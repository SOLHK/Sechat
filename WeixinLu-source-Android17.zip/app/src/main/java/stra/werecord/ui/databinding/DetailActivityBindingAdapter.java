/*
 * Copyright (c) 2021 xjunz. 保留所有权利
 */

package stra.werecord.ui.databinding;

import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.databinding.BindingAdapter;

import de.hdodenhof.circleimageview.CircleImageView;
import stra.werecord.R;
import stra.werecord.util.UiUtils;
import stra.werecord.util.Utils;

public class DetailActivityBindingAdapter {

    @BindingAdapter(value = "android:src")
    public static void setSrc(CircleImageView imageView, @Nullable Bitmap bitmap) {
        if (bitmap == null) {
            imageView.setImageResource(R.mipmap.avatar_default);
        } else {
            imageView.setImageBitmap(bitmap);
        }
    }


    @BindingAdapter("android:copyable")
    public static void setCopyable(TextView textView, boolean isCopyable) {
        if (isCopyable) {
            Drawable drawable = textView.getContext().getTheme().getDrawable(R.drawable.bg_clickable_text).mutate();
            textView.setClickable(true);
            textView.setFocusable(true);
            textView.setBackground(drawable);
            textView.setOnClickListener(v -> {
                Utils.copyPlainText("From 微信路", textView.getText());
                UiUtils.toast(R.string.has_copied_to_clipboard);
            });
        }
    }
}
