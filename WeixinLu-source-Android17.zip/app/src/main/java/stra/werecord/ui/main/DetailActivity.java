/*
 * Copyright (c) 2021 xjunz. 保留所有权利
 */

package stra.werecord.ui.main;

import android.annotation.SuppressLint;
import android.app.ActivityOptions;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.PopupMenu;

import androidx.annotation.Nullable;
import androidx.databinding.DataBindingUtil;

import org.jetbrains.annotations.NotNull;

import stra.werecord.BuildConfig;
import stra.werecord.R;
import stra.werecord.databinding.ActivityDetailBinding;
import stra.werecord.impl.DatabaseModifier;
import stra.werecord.impl.model.account.Contact;
import stra.werecord.impl.model.account.Talker;
import stra.werecord.impl.model.export.ExporterRegistry;
import stra.werecord.impl.model.export.MessageExporter;
import stra.werecord.impl.repo.ContactRepository;
import stra.werecord.impl.repo.RepositoryFactory;
import stra.werecord.ui.base.RecycleAwareActivity;
import stra.werecord.ui.customview.MasterToast;
import stra.werecord.ui.export.MessageExportActivity;
import stra.werecord.ui.message.MessageActivity;
import stra.werecord.ui.message.fragment.dialog.LvBufferEditorDialog;
import stra.werecord.util.RxJavaUtils;
import stra.werecord.util.UiUtils;

public class DetailActivity extends RecycleAwareActivity implements PopupMenu.OnMenuItemClickListener {
    public static final String EXTRA_CONTACT = "DetailActivity.extra.contact";
    public static final String EXTRA_CONTACT_ID = "DetailActivity.extra.ContactId";
    private Contact mData;
    private PopupMenu mPopupMenu;

    @Override
    protected void onCreateNormally(@Nullable Bundle savedInstanceState) {
        Intent intent = getIntent();
        ActivityDetailBinding binding = DataBindingUtil.setContentView(this, R.layout.activity_detail);
        mData = intent.getParcelableExtra(EXTRA_CONTACT);
        String id = intent.getStringExtra(EXTRA_CONTACT_ID);
        if (mData == null) {
            if (id == null) {
                MasterToast.shortToast("Got null data and null id.");
                finish();
                return;
            } else {
                binding.setId(id);
                mData = RepositoryFactory.get(ContactRepository.class).get(id);
            }
        }

        if (mData != null) {
            binding.setId(mData.id);
            binding.setContact(mData);
            boolean isTalker = mData instanceof Talker;
            if (isTalker) {
                binding.setTalker((Talker) mData);
            }
            initPopupMenu(binding.ibMore, isTalker);
        } else {
            UiUtils.gone(binding.ibMore);
        }

    }

    private void initPopupMenu(View anchor, boolean talker) {
            mPopupMenu = new PopupMenu(this, anchor);
            mPopupMenu.getMenuInflater().inflate(R.menu.contact_detail, mPopupMenu.getMenu());
            mPopupMenu.getMenu().findItem(R.id.item_mark_as_unread).setVisible(talker);
            mPopupMenu.getMenu().findItem(R.id.item_lv_buffer).setVisible(BuildConfig.DEBUG);
            updateMoreMenu();
            mPopupMenu.setOnMenuItemClickListener(this);
    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public boolean onMenuItemClick(@NotNull MenuItem item) {
        int id = item.getItemId();
        if ((id == R.id.item_delete_locally || id == R.id.item_mark_as_unread || id == R.id.item_add_to_local_friends || id == R.id.item_lv_buffer)
                && !stra.werecord.App.config().isEditModeEnabled()) {
            MasterToast.shortToast(R.string.edit_mode_not_enabled); return true;
        }
        if(id==R.id.item_check_messages) { checkMessages(null); return true; }
        if (id == R.id.item_delete_locally) {
                RxJavaUtils.complete(() -> {
                   /* if (modifier.deleteContactWithId(mData.id)) {
                        modifier.apply();
                    }*/
                }).subscribe(new RxJavaUtils.CompletableObservableAdapter() {
                    @Override
                    public void onComplete() {
                        super.onComplete();
                        MasterToast.shortToast("完成");
                    }

                    @Override
                    public void onError(@NotNull Throwable e) {
                        super.onError(e);
                        UiUtils.showError(DetailActivity.this, e);
                    }
                });
        } else if (id == R.id.item_mark_as_unread) {
            // Kept as an explicit no-op, matching the upstream menu behavior.
        } else if (id == R.id.item_lv_buffer) {
                new LvBufferEditorDialog().setTypeSerial(Contact.LV_BUFFER_READ_SERIAL).setDefault(mData.getParsedLvBuffer()).show(getSupportFragmentManager(), "lv_buffer");
        }
        return true;
    }

    public void viewImage(View view) {
        ActivityOptions options = ActivityOptions.makeSceneTransitionAnimation(this, view, view.getTransitionName());
        Intent i = new Intent(this, ImageViewerActivity.class);
        i.putExtra(ImageViewerActivity.EXTRA_ACCOUNT, mData);
        startActivity(i, options.toBundle());
    }

    public void checkMessages(View view) {
        try {
            Talker conversation=stra.werecord.ui.design.ContactConversation.from(mData);
            Intent i=new Intent(this,MessageActivity.class);
            i.putExtra(MessageActivity.EXTRA_TALKER,conversation);
            if(view==null) startActivity(i);
            else startActivity(i,ActivityOptions.makeSceneTransitionAnimation(this,view,view.getTransitionName()).toBundle());
        } catch(Exception error) { UiUtils.showError(this,error); }
    }

    public void showMore(View view) {
        if(mPopupMenu==null) return;
        updateMoreMenu();
        mPopupMenu.show();
    }

    private void updateMoreMenu() {
        boolean edit = stra.werecord.App.config().isEditModeEnabled();
        for (int id : new int[]{R.id.item_delete_locally, R.id.item_mark_as_unread, R.id.item_add_to_local_friends}) {
            mPopupMenu.getMenu().findItem(id).setVisible(edit && (id!=R.id.item_mark_as_unread || mData instanceof Talker));
        }
        mPopupMenu.getMenu().findItem(R.id.item_lv_buffer).setVisible(BuildConfig.DEBUG && edit);
    }


    public void exportMessages(View view) {
        if (mData != null) {
            Intent i = new Intent(this, MessageExportActivity.class);
            ExporterRegistry.getInstance().register(new MessageExporter((Talker) mData));
            startActivity(i, ActivityOptions.makeSceneTransitionAnimation(this, view, view.getTransitionName()).toBundle());
        }
    }
}
