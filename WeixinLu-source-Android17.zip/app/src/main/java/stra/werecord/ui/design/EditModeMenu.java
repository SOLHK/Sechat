package stra.werecord.ui.design;

import android.view.Menu;
import android.view.MenuItem;
import stra.werecord.R;

/** Keeps database-changing actions out of the viewing interface. */
public final class EditModeMenu {
    private EditModeMenu() {}

    public static boolean changesMessage(int id) {
        return id == R.id.item_edit || id == R.id.item_delete
                || id == R.id.item_add_before || id == R.id.item_add_after
                || id == R.id.item_restore;
    }

    public static void messages(Menu menu, boolean enabled, boolean edited) {
        for (int i = 0; i < menu.size(); i++) {
            MenuItem item = menu.getItem(i);
            if (changesMessage(item.getItemId())) {
                item.setVisible(enabled && (item.getItemId() != R.id.item_restore || edited));
            }
        }
    }

    public static void conversations(Menu menu, boolean enabled) {
        for (int i = 0; i < menu.size(); i++) {
            MenuItem item = menu.getItem(i);
            item.setVisible(enabled || item.getItemId() == R.id.item_export_message);
        }
    }
}
