package stra.werecord.ui.customview;

import android.content.Context;
import android.graphics.Matrix;
import android.graphics.Bitmap;
import android.view.*;
import androidx.appcompat.widget.AppCompatImageView;

/** One image, bounded decoded size, with pinch and double-tap viewing. */
public final class ZoomImageView extends AppCompatImageView {
    private final Matrix transform=new Matrix();
    private float base=1,zoom=1;
    private final ScaleGestureDetector scale;
    private final GestureDetector gestures;
    public ZoomImageView(Context context) {
        super(context);setScaleType(ScaleType.MATRIX);setContentDescription("聊天图片，可双指缩放或双击放大");
        scale=new ScaleGestureDetector(context,new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScale(ScaleGestureDetector detector) {
                float next=Math.max(1,Math.min(8,zoom*detector.getScaleFactor()));
                transform.postScale(next/zoom,next/zoom,detector.getFocusX(),detector.getFocusY());
                zoom=next;setImageMatrix(transform);return true;
            }
        });
        gestures=new GestureDetector(context,new GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onDown(MotionEvent event) { return true; }
            @Override public boolean onDoubleTap(MotionEvent event) {
                if(zoom>1) fit();else { transform.postScale(2,2,event.getX(),event.getY());zoom=2;setImageMatrix(transform); }
                return true;
            }
            @Override public boolean onScroll(MotionEvent a,MotionEvent b,float x,float y) {
                if(zoom>1 && !scale.isInProgress()) { transform.postTranslate(-x,-y);setImageMatrix(transform); }return true;
            }
        });
    }
    @Override public void setImageBitmap(Bitmap bitmap) { super.setImageBitmap(bitmap);if(transform!=null) fit(); }
    @Override protected void onSizeChanged(int w,int h,int oldw,int oldh) { super.onSizeChanged(w,h,oldw,oldh);fit(); }
    private void fit() {
        if(getDrawable()==null || getWidth()==0 || getHeight()==0) return;
        int w=getDrawable().getIntrinsicWidth(),h=getDrawable().getIntrinsicHeight();if(w<=0 || h<=0) return;
        base=Math.min(getWidth()/(float)w,getHeight()/(float)h);zoom=1;
        transform.setScale(base,base);transform.postTranslate((getWidth()-w*base)/2,(getHeight()-h*base)/2);setImageMatrix(transform);
    }
    @Override public boolean onTouchEvent(MotionEvent event) {
        scale.onTouchEvent(event);gestures.onTouchEvent(event);return true;
    }
}
