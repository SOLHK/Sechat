package stra.werecord.ui.design;
import android.view.View;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.graphics.Insets;

/** The native content is kept clear of system bars on edge-to-edge devices. */
public final class StraInsets {
    private StraInsets() {}
    public static void install(View root) {
        int left=root.getPaddingLeft(), top=root.getPaddingTop(), right=root.getPaddingRight(), bottom=root.getPaddingBottom();
        android.app.Activity activity=stra.werecord.util.ActivityUtils.getHostActivity(root.getContext());
        if (activity != null) {
            boolean light=(root.getResources().getConfiguration().uiMode & android.content.res.Configuration.UI_MODE_NIGHT_MASK)
                    != android.content.res.Configuration.UI_MODE_NIGHT_YES;
            androidx.core.view.WindowInsetsControllerCompat controller=androidx.core.view.WindowCompat.getInsetsController(activity.getWindow(), root);
            controller.setAppearanceLightStatusBars(light);
            controller.setAppearanceLightNavigationBars(light);
        }
        ViewCompat.setOnApplyWindowInsetsListener(root, (view, window) -> {
            Insets bars=window.getInsets(WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout() | WindowInsetsCompat.Type.ime());
            view.setPadding(left+bars.left,top+bars.top,right+bars.right,bottom+bars.bottom);
            return WindowInsetsCompat.CONSUMED;
        });
        ViewCompat.requestApplyInsets(root);
    }
}
