package stra.werecord.ui.design;
import android.view.View;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.graphics.Insets;

/** The native content is kept clear of system bars on edge-to-edge devices. */
public final class StraInsets {
    private StraInsets() {}
    public static void install(android.app.Activity activity, View root) {
        int left=root.getPaddingLeft(), top=root.getPaddingTop(), right=root.getPaddingRight(), bottom=root.getPaddingBottom();
        syncSystemBars(activity);
        ViewCompat.setOnApplyWindowInsetsListener(root, (view, window) -> {
            Insets bars=window.getInsets(WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout() | WindowInsetsCompat.Type.ime());
            view.setPadding(left+bars.left,top+bars.top,right+bars.right,bottom+bars.bottom);
            return WindowInsetsCompat.CONSUMED;
        });
        ViewCompat.requestApplyInsets(root);
    }
    /** DecorView may use a system/window context that does not wrap its Activity. */
    public static void syncSystemBars(android.app.Activity activity) {
        android.view.Window window=activity.getWindow();
        View decor=window.getDecorView();
        boolean light=activity.getResources().getBoolean(stra.werecord.R.bool.stra_light_bars);
        androidx.core.view.WindowInsetsControllerCompat controller=androidx.core.view.WindowCompat.getInsetsController(window, decor);
        controller.setAppearanceLightStatusBars(light);
        controller.setAppearanceLightNavigationBars(light);
    }
}
