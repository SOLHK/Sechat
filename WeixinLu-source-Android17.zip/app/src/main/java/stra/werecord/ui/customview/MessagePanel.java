package stra.werecord.ui.customview;
import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewpager2.widget.ViewPager2;
import java.util.ArrayList;
import stra.werecord.R;
import stra.werecord.util.ActivityUtils;

/** Conversation workspace with stable navigation and separate search input. */
public class MessagePanel extends ConstraintLayout {
    private ViewGroup curtain;
    private ViewPager2 pager;
    private View search;
    private boolean open;
    private final ArrayList<OnPanelSlideListener> listeners = new ArrayList<>();
    public MessagePanel(Context c) { super(c); }
    public MessagePanel(Context c, AttributeSet a) { super(c,a); }
    public MessagePanel(Context c, AttributeSet a, int d) { super(c,a,d); }
    @Override protected void onFinishInflate() {
        super.onFinishInflate();
        curtain=findViewById(R.id.ll_curtain); pager=findViewById(R.id.vp_message);
        search=findViewById(R.id.et_search);
        findViewById(R.id.ib_messages).setOnClickListener(v -> closePanel());
        findViewById(R.id.ib_stats).setOnClickListener(v -> select(0));
        findViewById(R.id.ib_edit).setOnClickListener(v -> select(1));
        findViewById(R.id.ib_search).setOnClickListener(v -> select(2));
        findViewById(R.id.ib_filter).setOnClickListener(v -> {
            if(open) closePanel(); else ActivityUtils.getHostActivity(getContext()).finishAfterTransition();
        });
        pager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override public void onPageSelected(int position) { updateNavigation(); }
        });
        curtain.setVisibility(GONE); updateNavigation();
    }
    private void select(int index) { pager.setCurrentItem(index,false); openPanel(); }
    private void updateNavigation() {
        int index=pager.getCurrentItem();
        findViewById(R.id.ib_messages).setSelected(!open);
        findViewById(R.id.ib_stats).setSelected(open && index==0);
        findViewById(R.id.ib_edit).setSelected(open && index==1);
        findViewById(R.id.ib_search).setSelected(open && index==2);
        search.setVisibility(open && index==2 ? VISIBLE : GONE);
        if (!open || index!=2) {
            stra.werecord.ui.base.BaseActivity.hideIme(search);
        }
    }
    public void addOnPanelSlideListener(OnPanelSlideListener listener) { listeners.add(listener); }
    public void openPanel() { setOpen(true); }
    public void closePanel() { setOpen(false); }
    private void setOpen(boolean value) {
        if(open==value) { updateNavigation(); return; }
        for(OnPanelSlideListener listener:listeners) listener.onPanelSlideStart(value);
        open=value; curtain.setVisibility(value ? VISIBLE : GONE); updateNavigation();
        for(OnPanelSlideListener listener:listeners) {
            listener.onPanelSlide(value ? 1f : 0f); listener.onPanelSlideFinished(value);
        }
    }
    public boolean isOpen() { return open; }
    public interface OnPanelSlideListener {
        void onPanelSlideFinished(boolean isOpen);
        void onPanelSlide(float fraction);
        void onPanelSlideStart(boolean isToOpen);
    }
}
