package stra.werecord.ui.design;

import android.graphics.*;
import android.graphics.drawable.Drawable;
import android.os.SystemClock;
import android.view.*;
import java.util.function.Supplier;

/** Small clipped backdrop sample: no full-screen bitmap and no recurring animation. */
public final class GlassBackdrop extends Drawable implements ViewTreeObserver.OnPreDrawListener {
    private final View owner;
    private final Supplier<View> source;
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG);
    private final RectF rect=new RectF();
    private final Path clip=new Path();
    private Bitmap sample;
    private int[] pixels, scratch;
    private final int[] a=new int[2],b=new int[2];
    private long lastSample;
    private boolean sampling, listening;
    public GlassBackdrop(View owner,Supplier<View> source) { this.owner=owner; this.source=source; }
    public void attach() {
        if(!listening) { owner.getViewTreeObserver().addOnPreDrawListener(this); listening=true; }
    }
    public void detach() {
        if(owner.getViewTreeObserver().isAlive()) owner.getViewTreeObserver().removeOnPreDrawListener(this);
        listening=false;
        if(sample!=null) sample.recycle(); sample=null; pixels=null; scratch=null;
    }
    public void sampleNow() {
        View content=source.get();
        if(sampling || content==null || content==owner || owner.getWidth()==0 || owner.getHeight()==0) return;
        sampling=true;
        try {
            int w=Math.max(1,owner.getWidth()/6),h=Math.max(1,owner.getHeight()/6);
            if(sample==null || sample.getWidth()!=w || sample.getHeight()!=h) {
                if(sample!=null) sample.recycle();
                sample=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);
                pixels=new int[w*h]; scratch=new int[w*h];
            }
            boolean dark=(owner.getResources().getConfiguration().uiMode&48)==32;
            sample.eraseColor(dark ? 0xff182533 : 0xfff4f6f8);
            owner.getLocationInWindow(a); content.getLocationInWindow(b);
            Canvas canvas=new Canvas(sample);
            canvas.scale(w/(float)owner.getWidth(),h/(float)owner.getHeight());
            canvas.translate(b[0]-a[0],b[1]-a[1]);
            content.draw(canvas);
            sample.getPixels(pixels,0,w,0,0,w,h);
            // Two tiny box-filter passes; only this navigation-sized crop is blurred.
            for(int pass=0;pass<2;pass++) {
                for(int y=0;y<h;y++) for(int x=0;x<w;x++) {
                    int red=0,green=0,blue=0,count=0;
                    for(int dy=-1;dy<=1;dy++) for(int dx=-1;dx<=1;dx++) {
                        int c=pixels[Math.max(0,Math.min(h-1,y+dy))*w+Math.max(0,Math.min(w-1,x+dx))];
                        red+=(c>>16)&255;green+=(c>>8)&255;blue+=c&255;count++;
                    }
                    scratch[y*w+x]=0xff000000|(red/count<<16)|(green/count<<8)|blue/count;
                }
                int[] swap=pixels; pixels=scratch; scratch=swap;
            }
            sample.setPixels(pixels,0,w,0,0,w,h);
        } finally { sampling=false; }
    }
    @Override public boolean onPreDraw() {
        long now=SystemClock.uptimeMillis();
        if(now-lastSample>=48 || sample==null) { sampleNow(); lastSample=now; }
        return true;
    }
    @Override public void draw(Canvas canvas) {
        if(sample==null && !sampling) sampleNow();
        rect.set(getBounds()); float radius=rect.height()/2;
        clip.reset();clip.addRoundRect(rect,radius,radius,Path.Direction.CW);
        int save=canvas.save(); canvas.clipPath(clip);
        paint.setStyle(Paint.Style.FILL);paint.setAlpha(255);
        if(sample!=null) canvas.drawBitmap(sample,null,rect,paint);
        boolean dark=(owner.getResources().getConfiguration().uiMode&48)==32;
        paint.setColor(dark?0xb0182533:0xb3ffffff);canvas.drawRoundRect(rect,radius,radius,paint);
        paint.setShader(new LinearGradient(0,rect.top,0,rect.bottom,new int[]{dark?0x25ffffff:0x70ffffff,0x00ffffff},null,Shader.TileMode.CLAMP));
        paint.setColor(Color.WHITE);canvas.drawRoundRect(rect,radius,radius,paint);paint.setShader(null);
        paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(owner.getResources().getDisplayMetrics().density);
        paint.setColor(dark?0x40ffffff:0xd9ffffff);rect.inset(.5f,.5f);canvas.drawRoundRect(rect,radius,radius,paint);
        paint.setStyle(Paint.Style.FILL);canvas.restoreToCount(save);
    }
    @Override public void getOutline(Outline outline) { outline.setRoundRect(getBounds(),getBounds().height()/2f); }
    @Override public void setAlpha(int alpha) { }
    @Override public void setColorFilter(ColorFilter filter) { }
    @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
}
