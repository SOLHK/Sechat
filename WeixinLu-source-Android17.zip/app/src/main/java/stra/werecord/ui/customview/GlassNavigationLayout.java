package stra.werecord.ui.customview;
import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.LinearLayout;
import stra.werecord.R;
import stra.werecord.ui.design.GlassBackdrop;
public class GlassNavigationLayout extends LinearLayout {
    private final GlassBackdrop glass;
    public GlassNavigationLayout(Context c,AttributeSet a) {
        super(c,a);
        glass=new GlassBackdrop(this,() -> {
            View root=getRootView(); View curtain=root.findViewById(R.id.ll_curtain);
            return curtain!=null && curtain.getVisibility()==VISIBLE ? curtain : root.findViewById(R.id.rv_message);
        });
        setBackground(glass);setClipToOutline(true);setElevation(3*getResources().getDisplayMetrics().density);
    }
    @Override protected void onAttachedToWindow() { super.onAttachedToWindow();glass.attach(); }
    @Override protected void onDetachedFromWindow() { glass.detach();super.onDetachedFromWindow(); }
}
