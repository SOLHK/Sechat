package stra.werecord.impl.media;

import java.io.IOException;
import java.util.*;
import java.util.regex.*;

/** Bounded exact-path lookup; never scan all of WeChat's media directory. */
public final class LocalImageFiles {
    public static final int MAX_BYTES=20*1024*1024;
    private LocalImageFiles() {}
    public static List<String> hashes(String... fields) {
        Set<String> result=new LinkedHashSet<>();
        Pattern pattern=Pattern.compile("(?i)(?<![a-f0-9])[a-f0-9]{32}(?![a-f0-9])");
        for(String field:fields) if(field!=null) {
            Matcher m=pattern.matcher(field);
            while(m.find() && result.size()<12) result.add(m.group().toLowerCase(Locale.ROOT));
        }
        return new ArrayList<>(result);
    }
    public static List<String> candidates(List<String> roots,List<String> hashes) {
        Set<String> result=new LinkedHashSet<>();
        // Originals from every root first, thumbnails only as a fallback.
        for(String prefix:new String[]{"","hd_","th_"}) for(String root:roots) for(String hash:hashes) {
            if(!hash.matches("[a-f0-9]{32}")) continue;
            for(String folder:new String[]{root+"/"+hash.substring(0,2)+"/"+hash.substring(2,4),root})
                for(String suffix:new String[]{"",".dat",".jpg",".png"}) result.add(folder+"/"+prefix+hash+suffix);
        }
        return new ArrayList<>(result);
    }
    public static String quote(String path) { return "'"+path.replace("'","'\\''")+"'"; }
    private static boolean matches(byte[] bytes,byte[] magic,int key,int offset) {
        if(bytes.length<offset+magic.length) return false;
        for(int i=0;i<magic.length;i++) if(((bytes[offset+i]&255)^key)!=(magic[i]&255)) return false;
        return true;
    }
    public static byte[] decodeContainer(byte[] bytes) throws IOException {
        byte[][] signatures={{(byte)0xff,(byte)0xd8,(byte)0xff},{(byte)0x89,0x50,0x4e,0x47,0x0d,0x0a,0x1a,0x0a},{0x47,0x49,0x46,0x38},{0x52,0x49,0x46,0x46}};
        if(bytes.length==0 || bytes.length>MAX_BYTES) throw new IOException("图片为空或超过20MB安全读取上限");
        for(int i=0;i<signatures.length;i++) {
            int key=(bytes[0]&255)^(signatures[i][0]&255);
            if(matches(bytes,signatures[i],key,0) && (i!=3 || matches(bytes,new byte[]{0x57,0x45,0x42,0x50},key,8))) {
                if(key==0) return bytes;
                byte[] plain=bytes.clone();for(int j=0;j<plain.length;j++) plain[j]=(byte)(plain[j]^key);return plain;
            }
        }
        StringBuilder header=new StringBuilder();for(int i=0;i<Math.min(8,bytes.length);i++)header.append(String.format(Locale.ROOT,"%02x",bytes[i]&255));
        throw new IOException("本地缓存不是支持的JPEG/PNG/GIF/WebP或单字节XOR图片。可能是新版加密容器；文件头："+header);
    }
    public static int sampleSize(int width,int height) throws IOException {
        if(width<=0 || height<=0) throw new IOException("无法识别图片尺寸");
        int sample=1;
        while(width/(long)sample*height/sample>2560000L || Math.max(width,height)/(long)sample>1600) sample*=2;
        return sample;
    }
}
