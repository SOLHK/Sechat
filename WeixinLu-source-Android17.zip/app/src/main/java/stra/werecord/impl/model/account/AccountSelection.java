package stra.werecord.impl.model.account;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/** Select only identities whose database has been found by the caller. */
public final class AccountSelection {
    private AccountSelection() {}
    public static List<String> candidates(String login, List<String> recorded) {
        Set<String> ids=new LinkedHashSet<>();
        add(ids,login);
        if(recorded!=null) for(String value:recorded) { if(ids.size()>=128) break; add(ids,value); }
        return new ArrayList<>(ids);
    }
    public static List<String> preferenceValues(String xml) {
        List<String> values=new ArrayList<>();
        if(xml==null) return values;
        java.util.regex.Matcher m=java.util.regex.Pattern.compile("value=[\"'](-?[0-9]{1,10})[\"']|>(-?[0-9]{1,10})<").matcher(xml);
        while(m.find()) values.add(m.group(1)!=null?m.group(1):m.group(2));
        return values;
    }
    private static void add(Set<String> ids,String value) {
        if(value==null || !value.trim().matches("-?[0-9]{1,10}")) return;
        long uin=Long.parseLong(value.trim());
        if(uin!=0 && uin>=Integer.MIN_VALUE && uin<=0xffffffffL) ids.add(value.trim());
    }
    public static String choose(List<String> available,String preferred,String login) {
        if(available.isEmpty()) throw new IllegalArgumentException("没有找到可读取的微信账号数据库");
        if(available.contains(preferred)) return preferred;
        if(available.contains(login)) return login;
        return available.get(0);
    }
}
