package stra.werecord.impl.media;

import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import java.io.*;
import java.nio.file.Files;
import java.util.*;
import stra.werecord.App;
import stra.werecord.impl.Environment;
import stra.werecord.impl.model.account.User;
import stra.werecord.impl.model.message.Message;
import stra.werecord.util.ShellUtils;

public final class MessageImageLoader {
    private MessageImageLoader() {}
    static Bitmap decodeBitmap(byte[] source) throws IOException {
        byte[] bytes=LocalImageFiles.decodeContainer(source);
        BitmapFactory.Options bounds=new BitmapFactory.Options();bounds.inJustDecodeBounds=true;
        BitmapFactory.decodeByteArray(bytes,0,bytes.length,bounds);
        BitmapFactory.Options options=new BitmapFactory.Options();options.inSampleSize=LocalImageFiles.sampleSize(bounds.outWidth,bounds.outHeight);
        Bitmap bitmap=BitmapFactory.decodeByteArray(bytes,0,bytes.length,options);
        if(bitmap==null) throw new IOException("图片解码返回空值");
        return bitmap;
    }
    public static Bitmap load(Message message) throws Exception {
        Environment env=Environment.getInstance();User user=env.getCurrentUser();
        List<String> fields=new ArrayList<>();fields.add(message.getImgPath());
        // Only md5 attributes identify an image; do not use aeskey as a filename or expose it.
        java.util.regex.Matcher md5=java.util.regex.Pattern.compile("(?i)\\bmd5\\s*=\\s*[\"']([a-f0-9]{32})[\"']").matcher(message.getRawContent()==null?"":message.getRawContent());
        while(md5.find()) fields.add(md5.group(1));
        String tableIssue="";
        try(Cursor cursor=env.getWorkerDatabase().rawQuery("select bigImgPath,midImgPath,thumbImgPath from ImgInfo2 where msglocalid=? limit 1",new String[]{Long.toString(message.getMsgId())})) {
            if(cursor.moveToFirst()) for(int i=0;i<3;i++) fields.add(cursor.getString(i));
        } catch(Exception error) { tableIssue="\nImgInfo2："+error.getClass().getSimpleName()+": "+error.getMessage(); }
        List<String> hashes=LocalImageFiles.hashes(fields.toArray(new String[0]));
        String hash=new File(user.dirPath).getName();String external=android.os.Environment.getExternalStorageDirectory().getPath();
        List<String> roots=Arrays.asList(user.dirPath+"/image2",external+"/Android/data/com.tencent.mm/MicroMsg/"+hash+"/image2",external+"/Android/data/com.tencent.mm/files/MicroMsg/"+hash+"/image2",user.imageCachePath);
        List<String> candidates=LocalImageFiles.candidates(roots,hashes);
        if(candidates.isEmpty()) throw new IOException("消息没有可识别的本地图片标识。msgId="+message.getMsgId()+"，imgPath="+message.getImgPath()+tableIssue);
        StringBuilder command=new StringBuilder("for f in ");
        for(String path:candidates) command.append(LocalImageFiles.quote(path)).append(' ');
        command.append("; do if [ -f \"$f\" ]; then printf '%s\\n' \"$f\"; fi; done");
        String found=ShellUtils.sudo(command.toString()).getStdout();
        if(found==null || found.trim().isEmpty()) throw new FileNotFoundException("没有找到本地图片缓存，可能尚未在微信下载或已清理。msgId="+message.getMsgId()+"\nimgPath="+message.getImgPath()+"\n检查目录："+roots+tableIssue);
        StringBuilder errors=new StringBuilder();int attempted=0;
        for(String path:found.split("\\r?\\n")) {
            if(!candidates.contains(path) || attempted++>=16) continue;
            File temp=File.createTempFile("message-image-",".cache",App.getContext().getCacheDir());
            try {
                String q=LocalImageFiles.quote(path), t=LocalImageFiles.quote(temp.getPath());
                ShellUtils.sudo("size=$(stat -c %s "+q+"); test \"$size\" -gt 0 && test \"$size\" -le "+LocalImageFiles.MAX_BYTES+" && head -c "+LocalImageFiles.MAX_BYTES+" "+q+" > "+t);
                return decodeBitmap(Files.readAllBytes(temp.toPath()));
            } catch(Exception error) { errors.append('\n').append(path).append("\n").append(error.getClass().getSimpleName()).append(": ").append(error.getMessage()); }
            finally { temp.delete(); }
        }
        throw new IOException("找到缓存但未能解码，msgId="+message.getMsgId()+errors+tableIssue);
    }
}
