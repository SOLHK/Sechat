package stra.werecord.impl.stats;

/** Small scalar SQL plan, independent of UI and full message decoding. */
public final class StatsQuery {
    private StatsQuery() {}
    public static String build(boolean groupChat) {
        String sender = groupChat
                ? "case when instr(substr(content,1,130),':' || char(10)) between 2 and 129 "
                    + "then substr(content,1,instr(substr(content,1,130),':' || char(10))-1) else null end"
                : "?";
        String identity = "case when type in (64,10000,10002,570425393,889192497,922746929) then null "
                + "when isSend!=0 then ? else " + sender + " end";
        return "select straType,straSender,count(*),min(straTime),max(straTime) from "
                + "(select type as straType," + identity + " as straSender,createTime as straTime "
                + "from message where talker=?) group by straType,straSender";
    }
}
