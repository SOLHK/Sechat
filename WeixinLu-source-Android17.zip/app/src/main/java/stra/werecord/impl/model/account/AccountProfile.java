package stra.werecord.impl.model.account;

import android.util.Xml;
import org.xmlpull.v1.XmlPullParser;
import java.io.StringReader;
import java.util.HashMap;
import java.util.Map;

/** Read-only fallback, scoped to the selected UIN to avoid another account's profile. */
public final class AccountProfile {
    public static Map<String,String> readPreferences(String xml) throws Exception {
        Map<String,String> values=new HashMap<>();
        XmlPullParser parser=Xml.newPullParser(); parser.setInput(new StringReader(xml));
        int event;
        while((event=parser.next())!=XmlPullParser.END_DOCUMENT) {
            if(event!=XmlPullParser.START_TAG) continue;
            String key=parser.getAttributeValue(null,"name");
            if(key==null || !key.startsWith("last_login_")) continue;
            String value=parser.getAttributeValue(null,"value");
            if(value==null && "string".equals(parser.getName())) value=parser.nextText();
            if(value!=null) values.put(key,value);
        }
        return values;
    }
    private static boolean empty(String s) { return s==null || s.trim().isEmpty(); }
    public static void apply(User user,Map<String,String> values) {
        String uin=values.get("last_login_uin");
        String id=values.get("last_login_username");
        if(!empty(uin)) {
            try { if((Long.parseLong(uin)&0xffffffffL)!=(Long.parseLong(user.uin)&0xffffffffL)) return; }
            catch(NumberFormatException ignored) { return; }
        } else if(empty(user.id) || !user.id.equals(id)) return;
        if(!empty(user.id) && !empty(id) && !user.id.equals(id)) return;
        if(empty(user.id) && !empty(id)) user.id=id;
        if(empty(user.nickname)) user.nickname=values.get("last_login_nick_name");
        if(empty(user.nickname)) user.nickname=values.get("last_login_nickname");
        if(empty(user.alias)) user.alias=values.get("last_login_alias");
    }
    private AccountProfile() { }
}
