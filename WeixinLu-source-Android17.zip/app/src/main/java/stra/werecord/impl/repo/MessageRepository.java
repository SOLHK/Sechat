/*
 * Copyright (c) 2021 xjunz. 保留所有权利
 */

package stra.werecord.impl.repo;

import android.content.ContentValues;
import android.util.ArrayMap;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import net.sqlcipher.Cursor;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import stra.werecord.impl.model.message.Message;
import stra.werecord.impl.model.message.MessageFactory;

import static stra.werecord.util.DbUtils.buildValuesFromCursor;

public class MessageRepository extends LifecyclePerceptiveRepository {
    public static final String TABLE_MESSAGE = "message";
    public static final String TABLE_APP_MESSAGE = "AppMessage";
    public static final String TABLE_MESSAGE_BACKUP = "MessageBackup";
    public static final String TABLE_APP_MESSAGE_BACKUP = "AppMessageBackup";


    private final ArrayMap<String, String> typeMap = new ArrayMap<>();

    MessageRepository() {
    }

    @Nullable
    public String getType(String colName) {
        return typeMap.get(colName);
    }


    @NonNull
    public String requireType(String colName) {
        return Objects.requireNonNull(typeMap.get(colName), "Could not find column: " + colName);
    }

    public void initTypeMap() {
        Cursor cursor = getDatabase().rawQuery("pragma table_info(" + TABLE_MESSAGE + ")", null);
        int nameIndex = cursor.getColumnIndex("name");
        int typeIndex = cursor.getColumnIndex("type");
        while (cursor.moveToNext()) {
            typeMap.put(cursor.getString(nameIndex), cursor.getString(typeIndex));
        }
        cursor.close();
        Cursor cursor2 = getDatabase().rawQuery("pragma table_info(" + TABLE_APP_MESSAGE + ")", null);
        while (cursor2.moveToNext()) {
            typeMap.put(cursor2.getString(nameIndex), cursor2.getString(typeIndex));
        }
        cursor2.close();
    }

    /**
     * 获得指定{@link stra.werecord.impl.model.account.Talker}的ID的实际消息数
     * <p>
     * {@link stra.werecord.impl.model.account.Talker#messageCount}获得的消息数
     * 来自"rconversation"表，是微信剔除了一些系统消息的消息数，不一定是"message"
     * 表里实际的消息数。
     *
     * @return 实际消息数
     * @see TalkerRepository#queryAll()
     * </p>
     */
    public long getActualMessageCountOf(String talkerId) {
        long count = 0;
        try (Cursor cursor = getDatabase().rawQuery("select count(msgId) from " + TABLE_MESSAGE + " where talker=?", new String[]{talkerId})) {
            if (cursor.moveToNext()) count = cursor.getLong(0);
        }
        return count;
    }

    /**
     * 查询指定微信ID的部分消息记录
     *
     * <p>此方法仅返回以{@param formerMsgList}的{@code size}为起始点的后{@param limitCount}条消息记录，不足则返回全部。
     * 记录以发送时间戳为排序依据，升序的形式排序。查询到的数据会追加进{@param formerMsgList}中。
     * </p>
     *
     * @param id            指定{@link stra.werecord.impl.model.account.Talker}的微信ID
     * @param limitCount    查询的消息数量，不足则全部查询
     * @param formerMsgList 储存数据的{@link List}，数据会被追加到此{@link List}中
     * @return 查询到的实际消息数
     */
    public int queryMessageByTalkerLimit(@NonNull String id, long limitCount, @NonNull List<Message> formerMsgList) {
        try (Cursor cursor = getDatabase().rawQuery("select * from " + TABLE_MESSAGE + " where talker=? order by createTime desc limit ? offset ?",
                new String[]{id, String.valueOf(limitCount), String.valueOf(formerMsgList.size())})) {
            while (cursor.moveToNext()) {
                formerMsgList.add(MessageFactory.createMessage(buildValuesFromCursor(cursor)));
            }
            return cursor.getCount();
        }
    }

    /**
     * 查询指定微信ID、指定消息起点和数量的消息记录，
     * 为了减少内存占用和查询时间，我们不会查询消息
     * 的所有字段，仅查询若干必要的字段
     * <p>
     * 记录以发送时间戳为排序依据，升序的形式排序
     * </p>
     *
     * @param id         微信ID
     * @param offset     起点
     * @param limitCount 消息数量
     * @return 查询到的消息列表
     */
    public List<Message> queryMessageByTalkerLimit(@NonNull String id, long offset, long limitCount) {
        List<Message> queried = new ArrayList<>();
        try (Cursor cursor = getDatabase().rawQuery("select * from " + TABLE_MESSAGE + " where talker=? order by createTime desc limit ? offset ?",
                new String[]{id, String.valueOf(limitCount), String.valueOf(offset)})) {
            while (cursor.moveToNext()) {
                queried.add(MessageFactory.createMessage(buildValuesFromCursor(cursor)));
            }
        }
        return queried;
    }

    /**
     * 读取统计需要的轻量消息页。只投影消息类型、时间、发送方向和内容，不读取图片路径、状态等无关列，
     * 让超大聊天记录可以分批统计而不把整段历史保存在内存里。
     */
    @NonNull
    public List<Message> queryMessagePageForStatistics(@NonNull String id, long beforeMsgId, int limitCount) {
        List<Message> queried = new ArrayList<>(limitCount);
        try (Cursor cursor = getDatabase().rawQuery(
                "select msgId,content,type,isSend,createTime,talker from " + TABLE_MESSAGE
                        + " where talker=? and msgId<? order by msgId desc limit ?",
                new String[]{id, String.valueOf(beforeMsgId), String.valueOf(limitCount)})) {
            while (cursor.moveToNext()) {
                queried.add(MessageFactory.createMessage(buildValuesFromCursor(cursor)));
            }
        }
        return queried;
    }

    public long getMaxMsgId() {
        long max = 0;
        Cursor cursor = getDatabase().rawQuery("select max(msgId) from " + TABLE_MESSAGE, null);
        if (cursor.moveToNext()) {
            max = cursor.getLong(0);
        }
        cursor.close();
        return max;
    }

    public List<Message> rawQueryMessageByTalker(@NonNull String whereClause) {
        List<Message> queried = new ArrayList<>();
        Cursor cursor = getDatabase().rawQuery(String.format("select * from %s where %s", TABLE_MESSAGE, whereClause), null);
        while (cursor.moveToNext()) {
            queried.add(MessageFactory.createMessage(buildValuesFromCursor(cursor)));
        }
        cursor.close();
        return queried;
    }

    /**
     * 从数据库中查询某消息记录，且记录其所有字段
     *
     * @param msgId 消息ID
     * @return 返回查询到的消息，如果未查询到返回null
     */
    @Nullable
    public Message queryMessageByMsgId(long msgId) {
        Cursor cursor = getDatabase().rawQuery("select * from " + TABLE_MESSAGE + " where msgId=" + msgId, null);
        if (cursor.moveToNext()) {
            Message message = MessageFactory.createMessage(buildValuesFromCursor(cursor));
            cursor.close();
            return message;
        }
        cursor.close();
        return null;
    }

    @Nullable
    public ContentValues queryAppContentValuesByMsgId(long msgId) {
        ContentValues values = null;
        Cursor cursor = getDatabase().rawQuery("select * from " + TABLE_APP_MESSAGE + " where msgId=" + msgId, null);
        if (cursor.moveToNext()) {
            values = buildValuesFromCursor(cursor);
        }
        cursor.close();
        return values;
    }

    @Nullable
    public ContentValues queryBackupAppContentValuesByMsgId(long msgId) {
        ContentValues values = null;
        Cursor cursor = getDatabase().rawQuery("select * from " + TABLE_APP_MESSAGE_BACKUP + " where msgId=" + msgId, null);
        if (cursor.moveToNext()) {
            values = buildValuesFromCursor(cursor);
        }
        cursor.close();
        return values;
    }

    @Nullable
    public ContentValues queryBackupContentValuesByMsgId(long msgId) {
        Cursor cursor = getDatabase().rawQuery("select * from " + TABLE_MESSAGE_BACKUP + " where msgId=" + msgId, null);
        if (cursor.moveToNext()) {
            return buildValuesFromCursor(cursor);
        }
        cursor.close();
        return null;
    }

    public Message queryBackupMessageById(long msgId) {
        Cursor cursor = getDatabase().rawQuery("select * from " + TABLE_MESSAGE_BACKUP + " where msgId=" + msgId, null);
        if (cursor.moveToNext()) {
            Message message = MessageFactory.createMessage(buildValuesFromCursor(cursor));
            cursor.close();
            return message;
        }
        cursor.close();
        return null;
    }

    public void queryBackupMessagesByTalker(String id, @NonNull List<Message> backupMessages) {
        try (Cursor cursor = getDatabase().rawQuery("select * from " + TABLE_MESSAGE_BACKUP + " where talker=? order by createTime desc", new String[]{id})) {
            while (cursor.moveToNext()) {
                backupMessages.add(MessageFactory.createMessage(buildValuesFromCursor(cursor)));
            }
        }
    }

}
