package stra.werecord.impl.repo;

/** Stable keyset pagination. Each query constructs at most one small page of messages. */
public final class MessageSearchQuery {
    public static final int PAGE_SIZE = 60;
    public static final String SQL = "select * from message where talker=? and content like ? escape '\\' "
            + "and (createTime<? or (createTime=? and msgId<?)) order by createTime desc,msgId desc limit ?";
    public static String[] args(String talker, String keyword, long time, long id) {
        String literal=keyword.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_");
        return new String[]{talker, "%"+literal+"%", String.valueOf(time), String.valueOf(time),
                String.valueOf(id), String.valueOf(PAGE_SIZE)};
    }
    private MessageSearchQuery() { }
}
