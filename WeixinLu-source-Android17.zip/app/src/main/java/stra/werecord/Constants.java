package stra.werecord;

public final class Constants {
    private Constants() {}
    public static volatile boolean USER_DEBUGGABLE = BuildConfig.DEBUG;
    public static final String URI_LAUNCH_QQ_TEMP_CHAT = "https://github.com/SOLHK/Sechat/issues";
    public static final String URI_JOIN_QQ_FEEDBACK_QQ_GROUP = "https://github.com/SOLHK/Sechat/issues";
    public static final String URI_PROJECT_REPOSITORY = "https://github.com/SOLHK/Sechat";
    public static final String URL_APP_DOWNLOAD_PAGE = "https://github.com/SOLHK/Sechat";
}
