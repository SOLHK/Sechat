/*
 * Copyright (c) 2021 xjunz. 保留所有权利
 */
package stra.werecord.util;

public interface Passable<P> {
    void pass(P passed);
}
