# Source and changes

- Upstream: https://github.com/xjunz/WeRecord
- Base ref: `data-binding` @ `ccd30d7b239fc3699f13ce559cb78f896d2ff602`
- Upstream and this fork are different from `pwh-pwh/wxrecordread`.
- Java package namespace changed from `xjunz.tool.werecord` to `stra.werecord`; installed application ID is `stra.werecord`.
- Existing database editing and deletion calls were retained. `DatabaseModifier.apply()` writes the working database back over WeChat's original database after force-stopping WeChat.
- Version 2.1.0 replaces the launcher dashboard with direct initialization and a Material 3 Expressive Views design: main navigation, workbench, statistics, help, onboarding, cards, message surfaces, and light/dark palettes.
- Navigation and the main filter sheet are new implementations. Statistics uses a new grouped scalar SQL query and bounded cache that checks database identity, local changes, and external data versions. Artificial message/contact loading delays were removed.
- Existing database models, editing/export operations, and parts of the View/Data Binding infrastructure remain derived from upstream. This is a refactored fork, not an independently rewritten application.
- Build SDK/target are API 36. The visual design follows current Expressive conventions; it does not claim to ship Android 17 platform APIs.
- Original copyright and license notices remain available in the project and the in-app license page.
- No LSPosed module metadata, entry point, or WeChat hook was added. `lsposed.zip` installs the framework, not this app as a module.
