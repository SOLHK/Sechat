# Source and changes

- Upstream: https://github.com/xjunz/WeRecord
- Base ref: `data-binding` @ `ccd30d7b239fc3699f13ce559cb78f896d2ff602`
- Upstream and this fork are different from `pwh-pwh/wxrecordread`.
- Java package namespace changed from `xjunz.tool.werecord` to `stra.werecord`; installed application ID is `stra.werecord`.
- Existing database editing and deletion calls were retained. `DatabaseModifier.apply()` writes the working database back over WeChat's original database after force-stopping WeChat.
- A Material 3 Compose launcher dashboard was added. Legacy data/tool screens remain upstream View/Data Binding screens for this build.
- No LSPosed module metadata, entry point, or WeChat hook was added. `lsposed.zip` installs the framework, not this app as a module.
