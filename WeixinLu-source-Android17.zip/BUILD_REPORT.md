# 微信路 2.1.2-private / versionCode 8

Package stra.werecord; minSdk 24; compile/target SDK 36.

UI update only: replaced the moving toolbar with fixed labeled conversation navigation and a separate search field; rebuilt the message list as sender/time record cards; condensed statistics to a numeric total, minute-level date range and thin comparison tracks; rebuilt the workbench as account summary, two data tiles and grouped preferences/utilities. System-bar contrast follows the active theme and content avoids the IME.

Retained SQL aggregate statistics/cache, paging, database write/delete/restore methods, editing-mode guards, raw-field viewer and copyable diagnostics. No database implementation changes.

Validation: fresh compile/tests pending. Added light/dark populated statistics, long-message wrapping and fixed-navigation tests. Device ROOT/SQLCipher behavior remains subject to live verification; the user reports fast statistics on the preceding 2.1.1 build.
Signing reuses certificate SHA256 f238e253fe09944e92fc9206685ebcf541c087db671050fbb4c154c41c0d831f.
