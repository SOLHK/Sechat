# 微信路 · Android 17 私用重制版构建报告

## Artifact

- App label: 微信路
- Application ID: `stra.werecord`
- Version: `2.0-private` (versionCode 3)
- Android SDK: minSdk 24; compileSdk/targetSdk 37 (Android 17 / API 37)
- Build toolchain: JDK 17, Gradle 9.3.1, Android Gradle Plugin 9.1.1
- APK signing: local debug key (v2); suitable for private testing, not production distribution

## Feature and compatibility status

| Area | Status |
|---|---|
| Local WeChat database editing, deletion, and writeback | Preserved from recovered `xjunz/WeRecord` source; `DatabaseModifier` and edit/restore/delete/writeback methods are present in the built APK. Requires ROOT access and a compatible WeChat data layout. Back up WeChat data before use. |
| LSPosed | Not integrated. This APK is a ROOT-based standalone app, not an LSPosed module; installing LSPosed does not activate it. |
| WeChat versions | No specific version claimed. Not tested against a live WeChat installation. |
| Android device runtime | APK builds and signature verifies, but no Android device/emulator was connected for install/runtime validation. |
| Hook status/features | No Xposed/LSPosed hooks are included in this recovered source fork. |

## Previous build verification

The earlier `assembleDebug` completed successfully with Gradle 9.3.1 and AGP 9.1.1. APK metadata reports API 37 / Android 17 and minSdk 24. `apksigner verify` passed using APK Signature Scheme v2. Static dex inspection confirmed the database modifier and the original message editing/deletion/restore paths are included.

## Source provenance and limitations

The source used is the archived public `xjunz/WeRecord` repository, branch `data-binding`, baseline commit `ccd30d7b239fc3699f13ce559cb78f896d2ff602`. It is not the deleted `pwh-pwh/wxrecordread` source repository. No standard upstream LICENSE file was present; upstream source comments reserve copyright. This build is for the user's private evaluation and should not be redistributed without resolving source licensing/permission.


## Root-check onboarding hotfix (2026-09-29)

The onboarding confirmation expected `app/src/main/assets/declaration.html`, but that asset was missing. `IntroActivity.gotoNext()` caught the resulting `IOException`, showed “发生错误”, and closed the onboarding activity. Added a local-use/data disclaimer asset. The hotfix APK includes that asset and retains the existing DEX unchanged; it was re-signed with the current debug key because the prior private signing key was unavailable. This hotfix artifact was validated with `apksigner` and metadata inspection; it was not fully rebuilt with Gradle or tested on-device. Its signing certificate differs from the previous APK, so install requires uninstalling the earlier build first.


## Latest source changes — not yet packaged

- Crash-log sending now opens the Android share chooser and attaches the local log using the FileProvider authority declared in the manifest. The user chooses the destination; there is no automatic send or upload.
- Opening a chat no longer eagerly reads every `MessageBackup` row; that query runs only when the edit/history page is opened. Message queries use bound arguments and close cursors.
- The launcher and branding use the new “微信路” name and custom road/speech-bubble icon. The home screen uses Material 3.
- The local build environment could not resolve the configured Android Gradle Plugin `9.1.1` from its offline cache. A GitHub Actions build succeeded using Android SDK 36 after applying compileSdk/targetSdk 36 to a temporary build copy; the published source configuration remains API 37. The debug APK was aligned and signed with the same local debug certificate as the root-check hotfix APK. It has not been run on a device.


## Large-chat statistics OOM fix

A device crash log from WeChat 8.0.72 showed `OutOfMemoryError` at 256 MiB while `StatisticsFragment.startAnalyze()` called `MessageActivity.loadAllMessages()`. That path loaded every message into `currentLoadedMessages`, in parallel. Statistics now scans the database in 100-row keyset pages, selects only the required columns, aggregates sender/type counts, and discards each page before reading the next. The fix avoids retaining the full conversation in memory. A fresh APK build is pending after this source update.
