# 微信路 2.1.1-private / versionCode 7

This project continues the supplied 2.1.0/2.1.1 source. SDK 36; package stra.werecord.

- Preserved direct InitializationActivity launcher, Material 3 screens, custom icons, aggregate statistics/cache and existing DatabaseModifier write/delete implementation.
- Raw message fields remain readable before parser-failure checks; viewer handles missing/restored dialog state and exposes copyable exception details.
- Viewing mode hides message edit/delete/insert/restore, history restore, apply-changes and conversation mutation entries. Dispatch paths re-check edit mode, including restore and editor results.
- About sheet contains name/version only; removed functional and personal-use explanations.
- History load/restore, search and full-message load errors show full copyable stack traces. Env status alone is not a stack trace.
- GitHub navigation targets SOLHK/Sechat.

Validation: pending fresh Gradle build/test. Signing will reuse the recovered key with certificate SHA256 f238e253fe09944e92fc9206685ebcf541c087db671050fbb4c154c41c0d831f.
Live ROOT/SQLCipher operations on OnePlus PKR110 / WeChat 8.0.72, 430k-record speed, and final database writeback still require device verification.
