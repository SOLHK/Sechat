# 微信路

Android ROOT 本地数据库工具，包名 `stra.werecord`，版本 `2.1.6-private` / `versionCode 12`。

使用已有工程继续开发，保留统计聚合与缓存、数据库编辑、删除和写回路径。此次改为 Telegram 式紧凑联系人行和左右消息气泡；关闭编辑模式时隐藏修改记录和修改入口；账户身份读取增加与当前UIN匹配的备用来源。

搜索由数据库分页执行，每页60条；消息浏览窗口最多600条，搜索定位加载目标附近100条，避免将43万条历史全部解析并留在内存。

## 构建

JDK 17、Android SDK/API 36、Build Tools 36.0.0、Gradle 9.3.1、AGP 9.1.1。minSdk24，targetSdk36。

`./gradlew --no-daemon --max-workers=2 testDebugUnitTest assembleDebug`

APK输出：`app/build/outputs/apk/debug/app-debug.apk`。签名密钥单独保管，不包含在公开源码中。项目地址：https://github.com/SOLHK/Sechat

原作者版权和组件许可见 `THIRD_PARTY_NOTICES.md` 与源码文件头。设备数据库操作及大数据量搜索速度仍需真机验证。详细改动与验证记录见 `BUILD_REPORT.md`。
