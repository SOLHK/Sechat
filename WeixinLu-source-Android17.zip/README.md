# 微信路 · Android 17 私用重制版

此工程基于 APK 所指向的公开上游仓库 `xjunz/WeRecord`，分支 `data-binding`，基线 commit `ccd30d7b239fc3699f13ce559cb78f896d2ff602`。应用 ID 已改为 `stra.werecord`，名称为“微信路”，使用 Android 17 / Material 3 风格首页及全新图标；上游原有 ROOT 数据库读取、编辑、删除、撤销与写回路径保留。

## 构建

- Android SDK Platform 37.0 / Build Tools 37.0.0
- JDK 17
- Gradle 9.3.1
- Android Gradle Plugin 9.1.1
- minSdk 24，targetSdk 37（Android 17）
- 构建命令：`./gradlew assembleDebug`
- APK：`app/build/outputs/apk/debug/app-debug.apk`

## 组件及行为

- 本工程是独立 ROOT 应用，包名 `stra.werecord`，不注册 Xposed/LSPosed 模块，也不提供 Hook。首页会明确显示这一点。
- `https://lsposed.zip/` 是 LSPosed 框架分发地址。安装框架不会自动把此 APK 变成模块；要支持 LSPosed，需要单独加入模块入口和经设备验证的 Hook 实现。
- 微信数据库编辑功能保留：原消息编辑、插入、删除、撤销/备份和将工作数据库写回微信原数据库的代码均来自上游 `DatabaseModifier`。写回路径会强停微信、复制工作库覆盖原库并清理 SQLite WAL/SHM 文件。请仅在个人设备和账号上使用，并先备份微信数据。
- 微信适配取决于 ROOT 环境、微信数据库格式与账号状态。本项目没有在真实设备或新微信版本上验证编辑、恢复或红包相关行为；Android 17 目标 SDK 编译不代表 LSPosed 或微信版本兼容。
- 新首页采用 Material 3 动态色彩与边到边布局；进入原有工具页后，目前仍沿用上游旧 View/Data Binding 页面。
- 崩溃日志按钮使用 Android 系统分享菜单，附件通过 FileProvider 提供，由用户自行选择接收应用或联系人；不会自动发送给原作者，也不会自动上传。
- 聊天列表进入时仅读取最近一页消息；备份消息延迟到用户主动打开编辑/历史页时加载，避免打开消息量很大的聊天时一次性把整份备份表载入内存。
- “显示修改”与“红包信息”尚未实现为 LSPosed Hook；本工程是 ROOT 独立应用。

## 上游资料

上游 README 声明该软件用于学习交流与演示。仓库没有标准 `LICENSE` 文件。本目录用于你的私用构建；不要把它当作具有明确再发布授权的衍生源码包。


### Root-check onboarding fix

The onboarding declaration asset is included at `app/src/main/assets/declaration.html`; without it, confirming the final setup step caused `IntroActivity` to show “发生错误” and close. The delivered hotfix package adds this asset. The hotfix binary is re-signed and requires removing a differently signed earlier build before installation.

### Crash-send and large-chat fixes (source state)

Crash log sharing now uses `ACTION_SEND` with the manifest-matched FileProvider authority and an Android chooser. The earlier `ACTION_VIEW` flow had no suitable handler for a text attachment and used a mismatched authority. Backup-message loading is deferred until the edition/history screen is opened. These latest source changes were not rebuilt in this workspace: Gradle could not resolve the configured Android Gradle Plugin offline, so the older hotfix APK does not contain these latest changes.
