# Third-party notices

TinyPinyin source files are included under `app/src/main/java/com/github/promeg/pinyinhelper/` to avoid depending on JitPack at build time.

- Project: https://github.com/promeG/TinyPinyin
- Included upstream license: `TINY_PINYIN_LICENSE.txt` (Apache License 2.0)
